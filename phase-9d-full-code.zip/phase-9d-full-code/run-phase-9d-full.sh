#!/usr/bin/env bash
set -euo pipefail

# Phase 9D — Real Payment Integration
# Run from repo root: /workspaces/corrastudiophoto

echo "================================================="
echo " Phase 9D Full — Real Payment Integration"
echo "================================================="

mkdir -p apps/booth-ui/src/payments
mkdir -p apps/booth-ui/src/booth
mkdir -p supabase/functions/create-mayar-checkout
mkdir -p supabase/functions/check-mayar-transaction-status
mkdir -p supabase/functions/mayar-payment-webhook
mkdir -p supabase/migrations
mkdir -p docs scripts

# -------------------------------------------------
# 9D0 Supabase table for unified payment intents
# -------------------------------------------------
cat > supabase/migrations/023_booth_payment_intents.sql <<'SQL'
create table if not exists public.booth_payment_intents (
  id uuid primary key default gen_random_uuid(),
  session_id text,
  provider text not null,
  status text not null default 'created',
  amount integer not null default 0,
  currency text not null default 'IDR',
  customer_name text,
  customer_email text,
  customer_phone text,
  provider_order_id text,
  provider_reference_id text,
  checkout_url text,
  qr_string text,
  qr_image_url text,
  raw_request jsonb not null default '{}'::jsonb,
  raw_response jsonb not null default '{}'::jsonb,
  paid_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists booth_payment_intents_session_id_idx
  on public.booth_payment_intents (session_id);

create index if not exists booth_payment_intents_provider_order_idx
  on public.booth_payment_intents (provider, provider_order_id);

create index if not exists booth_payment_intents_status_idx
  on public.booth_payment_intents (status);

alter table public.booth_payment_intents enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public'
      and tablename = 'booth_payment_intents'
      and policyname = 'Service role can manage booth payment intents'
  ) then
    create policy "Service role can manage booth payment intents"
      on public.booth_payment_intents
      for all
      using (auth.role() = 'service_role')
      with check (auth.role() = 'service_role');
  end if;
end $$;
SQL

# -------------------------------------------------
# 9D1 Edge: create Mayar checkout
# -------------------------------------------------
cat > supabase/functions/create-mayar-checkout/index.ts <<'TS'
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

type CreateMayarCheckoutRequest = {
  sessionId?: string;
  amount?: number;
  currency?: string;
  description?: string;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  successRedirectUrl?: string;
  failureRedirectUrl?: string;
  expiresInMinutes?: number;
};

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function cleanString(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}

function getAmount(value: unknown) {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error('amount must be a positive number.');
  }
  return Math.round(amount);
}

async function callMayar(apiKey: string, body: Record<string, unknown>) {
  const endpoints = [
    'https://api.mayar.id/hl/v1/payment/create',
    'https://api.mayar.id/v1/payment/create',
    'https://api.mayar.id/hl/v1/checkout/create',
  ];

  let lastError = '';

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      const text = await response.text();
      let parsed: Record<string, unknown> = {};

      try {
        parsed = text ? JSON.parse(text) : {};
      } catch {
        parsed = { rawText: text };
      }

      if (response.ok) {
        return { endpoint, response: parsed };
      }

      lastError = `${endpoint}: ${response.status} ${text}`;
    } catch (error) {
      lastError = error instanceof Error ? error.message : 'Unknown Mayar request error.';
    }
  }

  throw new Error(lastError || 'Mayar checkout request failed.');
}

function pickString(source: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
}

function pickNestedString(source: Record<string, unknown>, keys: string[]) {
  const candidates = [source];
  const data = source.data;
  if (data && typeof data === 'object') candidates.push(data as Record<string, unknown>);

  for (const candidate of candidates) {
    const result = pickString(candidate, keys);
    if (result) return result;
  }

  return '';
}

serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed.' }, 405);

  try {
    const mayarApiKey = Deno.env.get('MAYAR_API_KEY') || Deno.env.get('MAYAR_SECRET_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!mayarApiKey) throw new Error('Missing MAYAR_API_KEY Edge Function secret.');
    if (!supabaseUrl || !serviceRoleKey) throw new Error('Missing Supabase Edge Function env.');

    const payload = (await request.json()) as CreateMayarCheckoutRequest;
    const amount = getAmount(payload.amount);
    const sessionId = cleanString(payload.sessionId) || crypto.randomUUID();
    const customerName = cleanString(payload.customerName) || 'Corra Booth Customer';
    const customerEmail = cleanString(payload.customerEmail);
    const customerPhone = cleanString(payload.customerPhone);
    const description = cleanString(payload.description) || 'Corra Booth Photo Session';
    const currency = cleanString(payload.currency) || 'IDR';
    const expiresInMinutes = Number(payload.expiresInMinutes || 30);
    const expiresAt = new Date(Date.now() + expiresInMinutes * 60_000).toISOString();
    const orderId = `corra-${sessionId}-${Date.now()}`.replace(/[^a-zA-Z0-9-_]/g, '-');

    const requestBody = {
      name: description,
      description,
      amount,
      currency,
      referenceId: orderId,
      customer: {
        name: customerName,
        email: customerEmail || undefined,
        mobile: customerPhone || undefined,
      },
      redirectUrl: cleanString(payload.successRedirectUrl) || undefined,
      failureRedirectUrl: cleanString(payload.failureRedirectUrl) || undefined,
      expiredAt: expiresAt,
    };

    const mayarResult = await callMayar(mayarApiKey, requestBody);
    const responseBody = mayarResult.response;

    const checkoutUrl = pickNestedString(responseBody, [
      'checkoutUrl',
      'checkout_url',
      'paymentUrl',
      'payment_url',
      'url',
      'link',
    ]);

    const providerOrderId = pickNestedString(responseBody, [
      'id',
      'paymentId',
      'payment_id',
      'transactionId',
      'transaction_id',
      'invoiceId',
      'invoice_id',
      'referenceId',
      'reference_id',
    ]) || orderId;

    const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });

    await supabase.from('booth_payment_intents').insert({
      session_id: sessionId,
      provider: 'MAYAR_CHECKOUT',
      status: 'pending',
      amount,
      currency,
      customer_name: customerName,
      customer_email: customerEmail || null,
      customer_phone: customerPhone || null,
      provider_order_id: providerOrderId,
      provider_reference_id: orderId,
      checkout_url: checkoutUrl || null,
      raw_request: requestBody,
      raw_response: { endpoint: mayarResult.endpoint, response: responseBody },
      expires_at: expiresAt,
    });

    return json({
      ok: true,
      provider: 'MAYAR_CHECKOUT',
      sessionId,
      amount,
      currency,
      status: 'pending',
      providerOrderId,
      providerReferenceId: orderId,
      checkoutUrl,
      expiresAt,
      raw: responseBody,
    });
  } catch (error) {
    return json({ ok: false, error: error instanceof Error ? error.message : 'Unknown error.' }, 400);
  }
});
TS

# -------------------------------------------------
# 9D2 Edge: check Mayar transaction status
# -------------------------------------------------
cat > supabase/functions/check-mayar-transaction-status/index.ts <<'TS'
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

type CheckStatusRequest = {
  providerOrderId?: string;
  providerReferenceId?: string;
  sessionId?: string;
};

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function cleanString(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}

function normalizeStatus(value: unknown) {
  const status = typeof value === 'string' ? value.toLowerCase() : '';

  if (['paid', 'success', 'successful', 'settlement', 'settled', 'completed', 'complete'].includes(status)) {
    return 'paid';
  }

  if (['expired', 'expire', 'cancelled', 'canceled', 'failed', 'deny'].includes(status)) {
    return 'failed';
  }

  if (['pending', 'waiting', 'unpaid', 'created', 'process'].includes(status)) {
    return 'pending';
  }

  return status || 'pending';
}

function pickStatus(source: Record<string, unknown>) {
  const candidates = [source];
  const data = source.data;
  if (data && typeof data === 'object') candidates.push(data as Record<string, unknown>);

  for (const candidate of candidates) {
    for (const key of ['status', 'paymentStatus', 'payment_status', 'transactionStatus', 'transaction_status']) {
      const value = candidate[key];
      if (typeof value === 'string' && value.trim()) return normalizeStatus(value);
    }
  }

  return 'pending';
}

async function fetchMayarStatus(apiKey: string, id: string) {
  const endpoints = [
    `https://api.mayar.id/hl/v1/payment/${encodeURIComponent(id)}`,
    `https://api.mayar.id/v1/payment/${encodeURIComponent(id)}`,
    `https://api.mayar.id/hl/v1/transaction/${encodeURIComponent(id)}`,
    `https://api.mayar.id/v1/transaction/${encodeURIComponent(id)}`,
  ];

  let lastError = '';

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(endpoint, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      const text = await response.text();
      let parsed: Record<string, unknown> = {};

      try {
        parsed = text ? JSON.parse(text) : {};
      } catch {
        parsed = { rawText: text };
      }

      if (response.ok) return { endpoint, response: parsed };
      lastError = `${endpoint}: ${response.status} ${text}`;
    } catch (error) {
      lastError = error instanceof Error ? error.message : 'Unknown Mayar status error.';
    }
  }

  throw new Error(lastError || 'Mayar status request failed.');
}

serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed.' }, 405);

  try {
    const mayarApiKey = Deno.env.get('MAYAR_API_KEY') || Deno.env.get('MAYAR_SECRET_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!mayarApiKey) throw new Error('Missing MAYAR_API_KEY Edge Function secret.');
    if (!supabaseUrl || !serviceRoleKey) throw new Error('Missing Supabase Edge Function env.');

    const payload = (await request.json()) as CheckStatusRequest;
    const providerOrderId = cleanString(payload.providerOrderId);
    const providerReferenceId = cleanString(payload.providerReferenceId);
    const sessionId = cleanString(payload.sessionId);
    const lookupId = providerOrderId || providerReferenceId || sessionId;

    if (!lookupId) throw new Error('providerOrderId, providerReferenceId, or sessionId is required.');

    const mayarResult = await fetchMayarStatus(mayarApiKey, lookupId);
    const status = pickStatus(mayarResult.response);
    const paidAt = status === 'paid' ? new Date().toISOString() : null;

    const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });

    let query = supabase.from('booth_payment_intents').update({
      status,
      raw_response: { statusEndpoint: mayarResult.endpoint, statusResponse: mayarResult.response },
      paid_at: paidAt,
      updated_at: new Date().toISOString(),
    });

    if (providerOrderId) query = query.eq('provider_order_id', providerOrderId);
    else if (providerReferenceId) query = query.eq('provider_reference_id', providerReferenceId);
    else query = query.eq('session_id', sessionId);

    await query;

    return json({
      ok: true,
      provider: 'MAYAR_CHECKOUT',
      status,
      paidAt,
      providerOrderId,
      providerReferenceId,
      sessionId,
      raw: mayarResult.response,
    });
  } catch (error) {
    return json({ ok: false, error: error instanceof Error ? error.message : 'Unknown error.' }, 400);
  }
});
TS

# -------------------------------------------------
# 9D3 Edge: Mayar webhook receiver
# -------------------------------------------------
cat > supabase/functions/mayar-payment-webhook/index.ts <<'TS'
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-mayar-signature',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function normalizeStatus(value: unknown) {
  const status = typeof value === 'string' ? value.toLowerCase() : '';

  if (['paid', 'success', 'successful', 'settlement', 'settled', 'completed', 'complete'].includes(status)) return 'paid';
  if (['expired', 'expire', 'cancelled', 'canceled', 'failed', 'deny'].includes(status)) return 'failed';
  if (['pending', 'waiting', 'unpaid', 'created', 'process'].includes(status)) return 'pending';

  return status || 'pending';
}

function pickString(source: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
}

serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return json({ ok: false, error: 'Method not allowed.' }, 405);

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !serviceRoleKey) throw new Error('Missing Supabase Edge Function env.');

    const payload = (await request.json()) as Record<string, unknown>;
    const data = payload.data && typeof payload.data === 'object'
      ? payload.data as Record<string, unknown>
      : payload;

    const status = normalizeStatus(
      data.status || data.paymentStatus || data.payment_status || payload.status,
    );

    const providerOrderId = pickString(data, [
      'id',
      'paymentId',
      'payment_id',
      'transactionId',
      'transaction_id',
      'invoiceId',
      'invoice_id',
    ]);

    const providerReferenceId = pickString(data, [
      'referenceId',
      'reference_id',
      'externalId',
      'external_id',
    ]);

    const paidAt = status === 'paid'
      ? new Date().toISOString()
      : null;

    const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });

    let query = supabase.from('booth_payment_intents').update({
      status,
      raw_response: payload,
      paid_at: paidAt,
      updated_at: new Date().toISOString(),
    });

    if (providerOrderId) query = query.eq('provider_order_id', providerOrderId);
    else if (providerReferenceId) query = query.eq('provider_reference_id', providerReferenceId);
    else throw new Error('Webhook missing provider id/reference id.');

    await query;

    return json({ ok: true, status, providerOrderId, providerReferenceId });
  } catch (error) {
    return json({ ok: false, error: error instanceof Error ? error.message : 'Unknown error.' }, 400);
  }
});
TS

# -------------------------------------------------
# 9D4 Frontend types/storage/API
# -------------------------------------------------
cat > apps/booth-ui/src/payments/real-payment-types.ts <<'TS'
export type RealPaymentProvider =
  | 'STATIC_QRIS'
  | 'DOKU_QRIS'
  | 'MAYAR_CHECKOUT'
  | 'MANUAL_CASH';

export type RealPaymentIntentStatus =
  | 'idle'
  | 'created'
  | 'pending'
  | 'paid'
  | 'failed'
  | 'expired'
  | 'cancelled';

export type RealPaymentCustomer = {
  name?: string;
  email?: string;
  phone?: string;
};

export type RealPaymentIntent = {
  id: string;
  sessionId: string;
  provider: RealPaymentProvider;
  status: RealPaymentIntentStatus;
  amount: number;
  currency: string;
  description: string;
  checkoutUrl?: string;
  qrString?: string;
  qrImageUrl?: string;
  providerOrderId?: string;
  providerReferenceId?: string;
  customer?: RealPaymentCustomer;
  error?: string;
  createdAt: string;
  updatedAt: string;
  paidAt?: string;
  expiresAt?: string;
  raw?: unknown;
};

export type CreateRealPaymentIntentInput = {
  sessionId: string;
  provider: RealPaymentProvider;
  amount: number;
  currency?: string;
  description?: string;
  customer?: RealPaymentCustomer;
};

export type PaymentRuntimeSummary = {
  total: number;
  pending: number;
  paid: number;
  failed: number;
  expired: number;
};
TS

cat > apps/booth-ui/src/payments/real-payment-storage.ts <<'TS'
import type { PaymentRuntimeSummary, RealPaymentIntent } from './real-payment-types';

const INTENTS_KEY = 'corra.real.payment.intents.v1';

export function createClientId(prefix = 'payment') {
  if (typeof window !== 'undefined' && window.crypto?.randomUUID) {
    return `${prefix}-${window.crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function loadRealPaymentIntents(): RealPaymentIntent[] {
  if (typeof window === 'undefined') return [];

  try {
    const raw = window.localStorage.getItem(INTENTS_KEY);
    if (!raw) return [];

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed.filter((item) => item && typeof item.id === 'string');
  } catch {
    return [];
  }
}

export function saveRealPaymentIntents(intents: RealPaymentIntent[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(INTENTS_KEY, JSON.stringify(intents.slice(-300)));
}

export function upsertRealPaymentIntent(intent: RealPaymentIntent) {
  const intents = loadRealPaymentIntents();
  const index = intents.findIndex((candidate) => candidate.id === intent.id);
  const next = [...intents];

  if (index >= 0) next[index] = intent;
  else next.push(intent);

  saveRealPaymentIntents(next);
  return next;
}

export function summarizeRealPaymentIntents(
  intents: RealPaymentIntent[],
): PaymentRuntimeSummary {
  return intents.reduce(
    (acc, intent) => {
      acc.total += 1;
      if (intent.status === 'pending' || intent.status === 'created') acc.pending += 1;
      if (intent.status === 'paid') acc.paid += 1;
      if (intent.status === 'failed' || intent.status === 'cancelled') acc.failed += 1;
      if (intent.status === 'expired') acc.expired += 1;
      return acc;
    },
    { total: 0, pending: 0, paid: 0, failed: 0, expired: 0 },
  );
}
TS

cat > apps/booth-ui/src/payments/mayar-payment-api.ts <<'TS'
import type {
  CreateRealPaymentIntentInput,
  RealPaymentIntent,
  RealPaymentIntentStatus,
} from './real-payment-types';
import { createClientId } from './real-payment-storage';

export type CreateMayarCheckoutResponse = {
  ok: boolean;
  provider?: 'MAYAR_CHECKOUT';
  sessionId?: string;
  amount?: number;
  currency?: string;
  status?: RealPaymentIntentStatus;
  providerOrderId?: string;
  providerReferenceId?: string;
  checkoutUrl?: string;
  expiresAt?: string;
  raw?: unknown;
  error?: string;
};

export type CheckMayarStatusResponse = {
  ok: boolean;
  provider?: 'MAYAR_CHECKOUT';
  status?: RealPaymentIntentStatus;
  paidAt?: string | null;
  providerOrderId?: string;
  providerReferenceId?: string;
  sessionId?: string;
  raw?: unknown;
  error?: string;
};

export function getCreateMayarCheckoutUrl() {
  return import.meta.env.VITE_CREATE_MAYAR_CHECKOUT_URL || '';
}

export function getCheckMayarTransactionStatusUrl() {
  return import.meta.env.VITE_CHECK_MAYAR_TRANSACTION_STATUS_URL || '';
}

export async function createMayarCheckoutIntent(
  input: CreateRealPaymentIntentInput,
): Promise<RealPaymentIntent> {
  const url = getCreateMayarCheckoutUrl();
  if (!url) throw new Error('VITE_CREATE_MAYAR_CHECKOUT_URL is not configured.');

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      sessionId: input.sessionId,
      amount: input.amount,
      currency: input.currency || 'IDR',
      description: input.description || 'Corra Booth Photo Session',
      customerName: input.customer?.name,
      customerEmail: input.customer?.email,
      customerPhone: input.customer?.phone,
      expiresInMinutes: 30,
    }),
  });

  const result = (await response.json()) as CreateMayarCheckoutResponse;
  if (!response.ok || !result.ok) throw new Error(result.error || 'Failed to create Mayar checkout.');

  const now = new Date().toISOString();

  return {
    id: createClientId('mayar'),
    sessionId: result.sessionId || input.sessionId,
    provider: 'MAYAR_CHECKOUT',
    status: result.status || 'pending',
    amount: result.amount || input.amount,
    currency: result.currency || input.currency || 'IDR',
    description: input.description || 'Corra Booth Photo Session',
    checkoutUrl: result.checkoutUrl,
    providerOrderId: result.providerOrderId,
    providerReferenceId: result.providerReferenceId,
    customer: input.customer,
    createdAt: now,
    updatedAt: now,
    expiresAt: result.expiresAt,
    raw: result.raw,
  };
}

export async function checkMayarIntentStatus(
  intent: RealPaymentIntent,
): Promise<RealPaymentIntent> {
  const url = getCheckMayarTransactionStatusUrl();
  if (!url) throw new Error('VITE_CHECK_MAYAR_TRANSACTION_STATUS_URL is not configured.');

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      providerOrderId: intent.providerOrderId,
      providerReferenceId: intent.providerReferenceId,
      sessionId: intent.sessionId,
    }),
  });

  const result = (await response.json()) as CheckMayarStatusResponse;
  if (!response.ok || !result.ok) throw new Error(result.error || 'Failed to check Mayar status.');

  return {
    ...intent,
    status: result.status || intent.status,
    paidAt: result.paidAt || intent.paidAt,
    updatedAt: new Date().toISOString(),
    raw: result.raw || intent.raw,
  };
}
TS

cat > apps/booth-ui/src/payments/real-payment-api.ts <<'TS'
import type {
  CreateRealPaymentIntentInput,
  RealPaymentIntent,
} from './real-payment-types';
import { createClientId } from './real-payment-storage';
import { createMayarCheckoutIntent } from './mayar-payment-api';

export async function createRealPaymentIntent(
  input: CreateRealPaymentIntentInput,
): Promise<RealPaymentIntent> {
  if (input.provider === 'MAYAR_CHECKOUT') {
    return createMayarCheckoutIntent(input);
  }

  const now = new Date().toISOString();

  if (input.provider === 'MANUAL_CASH') {
    return {
      id: createClientId('cash'),
      sessionId: input.sessionId,
      provider: 'MANUAL_CASH',
      status: 'pending',
      amount: input.amount,
      currency: input.currency || 'IDR',
      description: input.description || 'Manual cash payment',
      customer: input.customer,
      createdAt: now,
      updatedAt: now,
    };
  }

  if (input.provider === 'STATIC_QRIS') {
    return {
      id: createClientId('static-qris'),
      sessionId: input.sessionId,
      provider: 'STATIC_QRIS',
      status: 'pending',
      amount: input.amount,
      currency: input.currency || 'IDR',
      description: input.description || 'Static QRIS payment',
      customer: input.customer,
      createdAt: now,
      updatedAt: now,
    };
  }

  return {
    id: createClientId('doku'),
    sessionId: input.sessionId,
    provider: 'DOKU_QRIS',
    status: 'pending',
    amount: input.amount,
    currency: input.currency || 'IDR',
    description: input.description || 'DOKU QRIS payment',
    customer: input.customer,
    createdAt: now,
    updatedAt: now,
    error: 'DOKU runtime bridge should reuse existing 8D APIs in the next hardening pass.',
  };
}
TS

cat > apps/booth-ui/src/payments/index.ts <<'TS'
export * from './real-payment-types';
export * from './real-payment-storage';
export * from './real-payment-api';
export * from './mayar-payment-api';
TS

# -------------------------------------------------
# 9D5 UI panels
# -------------------------------------------------
cat > apps/booth-ui/src/payments/RealPaymentRuntimePanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import { checkMayarIntentStatus } from './mayar-payment-api';
import { createRealPaymentIntent } from './real-payment-api';
import {
  loadRealPaymentIntents,
  saveRealPaymentIntents,
  summarizeRealPaymentIntents,
  upsertRealPaymentIntent,
} from './real-payment-storage';
import type { RealPaymentIntent, RealPaymentProvider } from './real-payment-types';

type Props = {
  sessionId?: string;
  defaultAmount?: number;
};

export function RealPaymentRuntimePanel({ sessionId, defaultAmount = 25000 }: Props) {
  const [intents, setIntents] = useState(() => loadRealPaymentIntents());
  const [provider, setProvider] = useState<RealPaymentProvider>('MAYAR_CHECKOUT');
  const [amount, setAmount] = useState(defaultAmount);
  const [customerName, setCustomerName] = useState('Corra Booth Customer');
  const [customerEmail, setCustomerEmail] = useState('');
  const [isBusy, setIsBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const summary = useMemo(() => summarizeRealPaymentIntents(intents), [intents]);
  const recent = intents.slice(-5).reverse();

  const refresh = () => {
    setIntents(loadRealPaymentIntents());
    setMessage('Payment intents refreshed.');
    setError('');
  };

  const saveAndSet = (next: RealPaymentIntent[]) => {
    saveRealPaymentIntents(next);
    setIntents(next);
  };

  const createIntent = async () => {
    setIsBusy(true);
    setMessage('');
    setError('');

    try {
      const intent = await createRealPaymentIntent({
        sessionId: sessionId || `manual-${Date.now()}`,
        provider,
        amount,
        currency: 'IDR',
        description: 'Corra Booth Photo Session',
        customer: {
          name: customerName,
          email: customerEmail || undefined,
        },
      });

      const next = upsertRealPaymentIntent(intent);
      setIntents(next);
      setMessage('Payment intent created.');

      if (intent.checkoutUrl) {
        window.open(intent.checkoutUrl, '_blank', 'noopener,noreferrer');
      }
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : 'Create payment failed.');
    } finally {
      setIsBusy(false);
    }
  };

  const markPaid = (intent: RealPaymentIntent) => {
    const nextIntent: RealPaymentIntent = {
      ...intent,
      status: 'paid',
      paidAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const next = upsertRealPaymentIntent(nextIntent);
    setIntents(next);
    setMessage('Intent marked paid locally.');
  };

  const checkStatus = async (intent: RealPaymentIntent) => {
    setIsBusy(true);
    setMessage('');
    setError('');

    try {
      if (intent.provider !== 'MAYAR_CHECKOUT') {
        setMessage('Status check currently implemented for Mayar only.');
        return;
      }

      const nextIntent = await checkMayarIntentStatus(intent);
      const next = upsertRealPaymentIntent(nextIntent);
      setIntents(next);
      setMessage(`Status: ${nextIntent.status}`);
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : 'Status check failed.');
    } finally {
      setIsBusy(false);
    }
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Real Payment Runtime
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Create checkout, open payment URL, poll status, and keep local payment intents.
          </p>
        </div>

        <button
          type="button"
          onClick={refresh}
          className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white"
        >
          Refresh
        </button>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-4">
        <div className="rounded-2xl bg-white/10 p-3">
          <p className="text-xs font-black uppercase text-white/40">Total</p>
          <p className="mt-1 text-2xl font-black text-white">{summary.total}</p>
        </div>
        <div className="rounded-2xl bg-amber-500/20 p-3">
          <p className="text-xs font-black uppercase text-amber-100">Pending</p>
          <p className="mt-1 text-2xl font-black text-white">{summary.pending}</p>
        </div>
        <div className="rounded-2xl bg-emerald-500/20 p-3">
          <p className="text-xs font-black uppercase text-emerald-100">Paid</p>
          <p className="mt-1 text-2xl font-black text-white">{summary.paid}</p>
        </div>
        <div className="rounded-2xl bg-red-500/20 p-3">
          <p className="text-xs font-black uppercase text-red-100">Failed/Expired</p>
          <p className="mt-1 text-2xl font-black text-white">{summary.failed + summary.expired}</p>
        </div>
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-4">
        <select
          value={provider}
          onChange={(event) => setProvider(event.target.value as RealPaymentProvider)}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
        >
          <option value="MAYAR_CHECKOUT">Mayar Checkout</option>
          <option value="DOKU_QRIS">DOKU QRIS</option>
          <option value="STATIC_QRIS">Static QRIS</option>
          <option value="MANUAL_CASH">Manual Cash</option>
        </select>

        <input
          type="number"
          value={amount}
          onChange={(event) => setAmount(Number(event.target.value))}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
          placeholder="Amount"
        />

        <input
          value={customerName}
          onChange={(event) => setCustomerName(event.target.value)}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
          placeholder="Customer name"
        />

        <input
          value={customerEmail}
          onChange={(event) => setCustomerEmail(event.target.value)}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
          placeholder="Customer email optional"
        />
      </div>

      <button
        type="button"
        onClick={() => void createIntent()}
        disabled={isBusy}
        className="mt-3 rounded-2xl bg-white px-4 py-3 text-xs font-black text-slate-950 disabled:opacity-40"
      >
        {isBusy ? 'Processing...' : 'Create Payment Intent'}
      </button>

      {message && (
        <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">
          {message}
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">
          {error}
        </div>
      )}

      <div className="mt-4 grid gap-2">
        {recent.map((intent) => (
          <div key={intent.id} className="rounded-2xl bg-white/10 p-3">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.14em] text-white">
                  {intent.provider} · {intent.status} · Rp {intent.amount.toLocaleString('id-ID')}
                </p>
                <p className="mt-1 break-all text-[11px] font-bold text-white/45">
                  session: {intent.sessionId}
                </p>
                {intent.checkoutUrl && (
                  <p className="mt-1 break-all text-[11px] font-bold text-white/45">
                    {intent.checkoutUrl}
                  </p>
                )}
                {intent.error && (
                  <p className="mt-1 text-[11px] font-bold text-red-200">{intent.error}</p>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                {intent.checkoutUrl && (
                  <a
                    href={intent.checkoutUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"
                  >
                    Open
                  </a>
                )}
                <button
                  type="button"
                  onClick={() => void checkStatus(intent)}
                  disabled={isBusy}
                  className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white disabled:opacity-40"
                >
                  Check
                </button>
                <button
                  type="button"
                  onClick={() => markPaid(intent)}
                  className="rounded-2xl border border-emerald-300/30 bg-emerald-500/20 px-3 py-2 text-xs font-black text-emerald-100"
                >
                  Mark Paid
                </button>
              </div>
            </div>
          </div>
        ))}

        {recent.length === 0 && (
          <div className="rounded-2xl bg-white/10 p-3 text-xs font-bold text-white/50">
            No real payment intents yet.
          </div>
        )}
      </div>
    </section>
  );
}
TSX

cat > apps/booth-ui/src/payments/PaymentProviderDiagnosticsPanel.tsx <<'TSX'
import React from 'react';
import {
  getCheckMayarTransactionStatusUrl,
  getCreateMayarCheckoutUrl,
} from './mayar-payment-api';

export function PaymentProviderDiagnosticsPanel() {
  const mayarCreateUrl = getCreateMayarCheckoutUrl();
  const mayarCheckUrl = getCheckMayarTransactionStatusUrl();

  const rows = [
    ['Mayar create checkout', mayarCreateUrl],
    ['Mayar check status', mayarCheckUrl],
    ['DOKU QRIS', import.meta.env.VITE_CREATE_DOKU_QRIS_URL || ''],
    ['DOKU check status', import.meta.env.VITE_CHECK_DOKU_QRIS_STATUS_URL || ''],
  ];

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
        Payment Provider Diagnostics
      </p>
      <div className="mt-4 grid gap-2">
        {rows.map(([label, value]) => (
          <div key={label} className="rounded-2xl bg-white/10 p-3">
            <p className="text-xs font-black uppercase text-white">{label}</p>
            <p className={value ? 'mt-1 break-all text-xs font-bold text-emerald-100' : 'mt-1 text-xs font-bold text-red-200'}>
              {value || 'Not configured'}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
TSX

cat >> apps/booth-ui/src/payments/index.ts <<'TS'
export * from './RealPaymentRuntimePanel';
export * from './PaymentProviderDiagnosticsPanel';
TS

# -------------------------------------------------
# 9D6 Integrate dev panels into BoothCustomerScreen
# -------------------------------------------------
python - <<'PY'
from pathlib import Path

path = Path("apps/booth-ui/src/booth/BoothCustomerScreen.tsx")
if not path.exists():
    print("WARN: BoothCustomerScreen.tsx not found; skipping UI integration.")
    raise SystemExit(0)

text = path.read_text()
imports = [
    "import { PaymentProviderDiagnosticsPanel, RealPaymentRuntimePanel } from '../payments';",
]

for line in imports:
    if line not in text:
        lines = text.splitlines()
        insert_at = 0
        for index, existing in enumerate(lines):
            if existing.startswith("import "):
                insert_at = index + 1
        lines.insert(insert_at, line)
        text = "\n".join(lines) + "\n"

if "<RealPaymentRuntimePanel" not in text:
    marker = """            <div className=\"mt-4\">
              <BoothLifecycleDebugPanel />
            </div>"""
    addition = marker + """

            <div className=\"mt-4\">
              <PaymentProviderDiagnosticsPanel />
            </div>

            <div className=\"mt-4\">
              <RealPaymentRuntimePanel sessionId={session?.id} />
            </div>"""
    if marker in text:
        text = text.replace(marker, addition, 1)
    else:
        print("WARN: LifecycleDebugPanel marker not found; payment panels not inserted.")

path.write_text(text)
print("PATCH:", path)
PY

# -------------------------------------------------
# 9D7 env
# -------------------------------------------------
ENV_FILE="apps/booth-ui/.env.local"
touch "$ENV_FILE"

if ! grep -q "^VITE_CREATE_MAYAR_CHECKOUT_URL=" "$ENV_FILE"; then
  cat >> "$ENV_FILE" <<'ENV'

VITE_CREATE_MAYAR_CHECKOUT_URL=https://uitnzrstkjvwiojbnpwg.supabase.co/functions/v1/create-mayar-checkout
ENV
fi

if ! grep -q "^VITE_CHECK_MAYAR_TRANSACTION_STATUS_URL=" "$ENV_FILE"; then
  cat >> "$ENV_FILE" <<'ENV'
VITE_CHECK_MAYAR_TRANSACTION_STATUS_URL=https://uitnzrstkjvwiojbnpwg.supabase.co/functions/v1/check-mayar-transaction-status
ENV
fi

if ! grep -q "^VITE_MAYAR_PAYMENT_WEBHOOK_URL=" "$ENV_FILE"; then
  cat >> "$ENV_FILE" <<'ENV'
VITE_MAYAR_PAYMENT_WEBHOOK_URL=https://uitnzrstkjvwiojbnpwg.supabase.co/functions/v1/mayar-payment-webhook
ENV
fi

# -------------------------------------------------
# 9D8 docs/checker
# -------------------------------------------------
cat > docs/phase-9d-real-payment-integration.md <<'MD'
# Phase 9D — Real Payment Integration

Scope:
- Unified payment intent table
- Mayar checkout create function
- Mayar status check function
- Mayar webhook receiver
- Frontend payment runtime storage
- Frontend runtime payment test panel
- Provider diagnostics panel

Deploy:
```bash
pnpm dlx supabase db push
pnpm dlx supabase functions deploy create-mayar-checkout --no-verify-jwt
pnpm dlx supabase functions deploy check-mayar-transaction-status --no-verify-jwt
pnpm dlx supabase functions deploy mayar-payment-webhook --no-verify-jwt
```

Required Edge Function secret:
```bash
pnpm dlx supabase secrets set MAYAR_API_KEY=your_mayar_api_key
```

Test:
```txt
?mode=booth&dev=1
```

Known limitation:
- DOKU bridge is left as a placeholder because 8D already has DOKU functions and needs project-specific type reconciliation.
- For production, do not leave create/check/delete payment functions fully public without a booth/device token layer.
MD

cat > docs/phase-9d-status.md <<'MD'
# Phase 9D Status

9D1 payment intents table: added
9D2 Mayar checkout: added
9D3 Mayar status check: added
9D4 Mayar webhook: added
9D5 frontend real payment runtime: added
9D6 diagnostics panel: added
9D7 booth dev integration: added
9D8 close docs/checker: added

Next recommended phase:
- 9E Electron Disk Persistence
MD

cat > scripts/check-phase-9d-status.sh <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail

f(){ [ -f "$2" ] && echo "✅ $1" || echo "❌ $1"; }

echo "Phase 9D Status"
echo "==============="

f "9D0 migration" supabase/migrations/023_booth_payment_intents.sql
f "9D1 create Mayar" supabase/functions/create-mayar-checkout/index.ts
f "9D2 check Mayar" supabase/functions/check-mayar-transaction-status/index.ts
f "9D3 Mayar webhook" supabase/functions/mayar-payment-webhook/index.ts
f "9D4 payment types" apps/booth-ui/src/payments/real-payment-types.ts
f "9D4 payment storage" apps/booth-ui/src/payments/real-payment-storage.ts
f "9D4 Mayar API" apps/booth-ui/src/payments/mayar-payment-api.ts
f "9D4 real payment API" apps/booth-ui/src/payments/real-payment-api.ts
f "9D5 runtime panel" apps/booth-ui/src/payments/RealPaymentRuntimePanel.tsx
f "9D6 diagnostics panel" apps/booth-ui/src/payments/PaymentProviderDiagnosticsPanel.tsx
f "9D8 docs" docs/phase-9d-real-payment-integration.md

pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
CHECK

chmod +x scripts/check-phase-9d-status.sh

# -------------------------------------------------
# Optional: de-dupe payment exports
# -------------------------------------------------
python - <<'PY'
from pathlib import Path
path = Path("apps/booth-ui/src/payments/index.ts")
if path.exists():
    lines = path.read_text().splitlines()
    seen = set()
    out = []
    for line in lines:
        if line.startswith("export * from "):
            if line in seen:
                continue
            seen.add(line)
        out.append(line)
    path.write_text("\n".join(out) + "\n")
PY

echo ""
echo "Phase 9D full code scaffold written."
echo "Next commands:"
echo "  pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false"
echo "  ./scripts/check-phase-9d-status.sh"
echo "  pnpm dlx supabase db push"
echo "  pnpm dlx supabase secrets set MAYAR_API_KEY=your_mayar_api_key"
echo "  pnpm dlx supabase functions deploy create-mayar-checkout --no-verify-jwt"
echo "  pnpm dlx supabase functions deploy check-mayar-transaction-status --no-verify-jwt"
echo "  pnpm dlx supabase functions deploy mayar-payment-webhook --no-verify-jwt"
