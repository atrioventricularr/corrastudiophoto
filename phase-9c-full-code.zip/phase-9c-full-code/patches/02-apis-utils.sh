#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/booth-ui/src/booth

cat > apps/booth-ui/src/booth/booth-cloud-refresh-api.ts <<'TS'
import type { BoothCloudUploadRecord } from './booth-cloud-upload-types';

export type BoothSignedUrlRefreshResult = {
  ok: boolean;
  bucketName?: string;
  storagePath?: string;
  signedUrl?: string;
  signedUrlExpiresAt?: string;
  error?: string;
};

export function getRefreshBoothSignedUrlUrl() {
  return import.meta.env.VITE_REFRESH_BOOTH_SIGNED_URL_URL || '';
}

export async function refreshBoothSignedUrl(record: BoothCloudUploadRecord) {
  const refreshUrl = getRefreshBoothSignedUrlUrl();
  if (!refreshUrl) throw new Error('VITE_REFRESH_BOOTH_SIGNED_URL_URL is not configured.');

  const response = await fetch(refreshUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      bucketName: record.bucketName,
      storagePath: record.storagePath,
      expiresInSeconds: 60 * 60 * 24 * 7,
    }),
  });

  const result = (await response.json()) as BoothSignedUrlRefreshResult;
  if (!response.ok || !result.ok || !result.signedUrl || !result.signedUrlExpiresAt) {
    throw new Error(result.error || 'Failed to refresh signed URL.');
  }

  return { ...record, signedUrl: result.signedUrl, signedUrlExpiresAt: result.signedUrlExpiresAt };
}
TS

cat > apps/booth-ui/src/booth/booth-cloud-delete-api.ts <<'TS'
import type { BoothCloudUploadRecord } from './booth-cloud-upload-types';

export type BoothCloudDeleteResult = {
  ok: boolean;
  bucketName?: string;
  storagePath?: string;
  error?: string;
};

export function getDeleteBoothCloudAssetUrl() {
  return import.meta.env.VITE_DELETE_BOOTH_CLOUD_ASSET_URL || '';
}

export async function deleteBoothCloudAsset(record: BoothCloudUploadRecord) {
  const deleteUrl = getDeleteBoothCloudAssetUrl();
  if (!deleteUrl) throw new Error('VITE_DELETE_BOOTH_CLOUD_ASSET_URL is not configured.');

  const response = await fetch(deleteUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ bucketName: record.bucketName, storagePath: record.storagePath }),
  });

  const result = (await response.json()) as BoothCloudDeleteResult;
  if (!response.ok || !result.ok) throw new Error(result.error || 'Failed to delete cloud asset.');
  return result;
}
TS

cat > apps/booth-ui/src/booth/booth-cloud-upload-health.ts <<'TS'
import type { BoothCloudUploadRecord } from './booth-cloud-upload-types';

export type BoothCloudUploadRecordState = 'valid' | 'expiring_soon' | 'expired' | 'missing_signed_url';

export type BoothCloudUploadHealth = {
  total: number;
  valid: number;
  expiringSoon: number;
  expired: number;
  missingSignedUrl: number;
  nextExpiryAt?: string;
};

export function getCloudUploadRecordState(record: BoothCloudUploadRecord): BoothCloudUploadRecordState {
  if (!record.signedUrl || !record.signedUrlExpiresAt) return 'missing_signed_url';
  const expiry = new Date(record.signedUrlExpiresAt).getTime();
  if (!Number.isFinite(expiry)) return 'missing_signed_url';
  const remaining = expiry - Date.now();
  if (remaining <= 0) return 'expired';
  if (remaining <= 1000 * 60 * 60 * 12) return 'expiring_soon';
  return 'valid';
}

export function summarizeCloudUploadHealth(records: BoothCloudUploadRecord[]): BoothCloudUploadHealth {
  const summary: BoothCloudUploadHealth = { total: records.length, valid: 0, expiringSoon: 0, expired: 0, missingSignedUrl: 0 };
  const futureExpiries: number[] = [];

  for (const record of records) {
    const state = getCloudUploadRecordState(record);
    if (state === 'valid') summary.valid += 1;
    if (state === 'expiring_soon') summary.expiringSoon += 1;
    if (state === 'expired') summary.expired += 1;
    if (state === 'missing_signed_url') summary.missingSignedUrl += 1;
    const expiry = new Date(record.signedUrlExpiresAt).getTime();
    if (Number.isFinite(expiry) && expiry > Date.now()) futureExpiries.push(expiry);
  }

  if (futureExpiries.length > 0) summary.nextExpiryAt = new Date(Math.min(...futureExpiries)).toISOString();
  return summary;
}
TS

cat > apps/booth-ui/src/booth/booth-cloud-upload-queue-types.ts <<'TS'
import type { BoothLocalAssetKind } from './booth-local-asset-types';

export type BoothCloudUploadQueueStatus = 'pending' | 'uploading' | 'uploaded' | 'failed';

export type BoothCloudUploadQueueItem = {
  id: string;
  assetId: string;
  sessionId: string;
  kind: BoothLocalAssetKind;
  filename: string;
  status: BoothCloudUploadQueueStatus;
  attempts: number;
  error?: string;
  createdAt: string;
  updatedAt: string;
};
TS

cat > apps/booth-ui/src/booth/booth-cloud-upload-queue-storage.ts <<'TS'
import type { BoothCloudUploadQueueItem, BoothCloudUploadQueueStatus } from './booth-cloud-upload-queue-types';
import type { BoothLocalAssetRecord } from './booth-local-asset-types';

const QUEUE_KEY = 'corra.booth.cloud.upload.queue.v1';

function makeId() {
  if (typeof window !== 'undefined' && window.crypto?.randomUUID) return `upload-queue-${window.crypto.randomUUID()}`;
  return `upload-queue-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function loadBoothCloudUploadQueue(): BoothCloudUploadQueueItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(QUEUE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((item) => item && typeof item.id === 'string') : [];
  } catch {
    return [];
  }
}

export function saveBoothCloudUploadQueue(items: BoothCloudUploadQueueItem[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(QUEUE_KEY, JSON.stringify(items.slice(-300)));
}

export function clearBoothCloudUploadQueue() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(QUEUE_KEY);
}

export function createQueueItemFromAsset(asset: BoothLocalAssetRecord): BoothCloudUploadQueueItem {
  const now = new Date().toISOString();
  return {
    id: makeId(),
    assetId: asset.id,
    sessionId: asset.sessionId,
    kind: asset.kind,
    filename: asset.filename,
    status: 'pending',
    attempts: 0,
    createdAt: now,
    updatedAt: now,
  };
}

export function updateQueueItemStatus(
  item: BoothCloudUploadQueueItem,
  status: BoothCloudUploadQueueStatus,
  error?: string,
): BoothCloudUploadQueueItem {
  return {
    ...item,
    status,
    attempts: status === 'uploading' || status === 'failed' ? item.attempts + 1 : item.attempts,
    error,
    updatedAt: new Date().toISOString(),
  };
}
TS

echo "9C APIs and utilities written."
