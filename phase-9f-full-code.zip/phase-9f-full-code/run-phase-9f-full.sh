#!/usr/bin/env bash
set -euo pipefail

echo "================================================="
echo " Phase 9F Full — Printer/Kiosk Hardware Testing"
echo "================================================="

mkdir -p apps/booth-ui/src/booth
mkdir -p apps/desktop-electron
mkdir -p docs scripts

cat > apps/desktop-electron/corra-hardware-diagnostics.cjs <<'CJS'
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const os = require('node:os');

function getActiveWindow() {
  return BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0] || null;
}

function safeHandle(channel, handler) {
  try {
    ipcMain.removeHandler(channel);
  } catch (_) {}

  ipcMain.handle(channel, handler);
}

safeHandle('corra:hardware-runtime-info', async () => {
  return {
    ok: true,
    appVersion: app?.getVersion ? app.getVersion() : 'unknown',
    platform: process.platform,
    arch: process.arch,
    node: process.versions.node,
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    hostname: os.hostname(),
    username: os.userInfo().username,
    userDataPath: app.getPath('userData'),
    tempPath: app.getPath('temp'),
    timestamp: new Date().toISOString(),
  };
});

safeHandle('corra:hardware-list-printers', async () => {
  const win = getActiveWindow();

  if (!win) {
    return { ok: false, error: 'No active BrowserWindow.', printers: [] };
  }

  try {
    const printers =
      typeof win.webContents.getPrintersAsync === 'function'
        ? await win.webContents.getPrintersAsync()
        : win.webContents.getPrinters();

    return {
      ok: true,
      printers: printers.map((printer) => ({
        name: printer.name,
        displayName: printer.displayName || printer.name,
        description: printer.description || '',
        status: printer.status || 0,
        isDefault: Boolean(printer.isDefault),
        options: printer.options || {},
      })),
    };
  } catch (error) {
    return {
      ok: false,
      error: error && error.message ? error.message : 'Failed to list printers.',
      printers: [],
    };
  }
});

safeHandle('corra:hardware-print-current-page', async (_event, payload) => {
  const win = getActiveWindow();

  if (!win) {
    return { ok: false, error: 'No active BrowserWindow.' };
  }

  const options = {
    silent: Boolean(payload && payload.silent),
    printBackground: true,
    deviceName: payload && payload.printerName ? String(payload.printerName) : undefined,
    copies: payload && payload.copies ? Number(payload.copies) : 1,
    pageSize: payload && payload.pageSize ? payload.pageSize : undefined,
  };

  return await new Promise((resolve) => {
    try {
      win.webContents.print(options, (success, failureReason) => {
        if (success) {
          resolve({ ok: true });
        } else {
          resolve({
            ok: false,
            error: failureReason || 'Print failed or cancelled.',
          });
        }
      });
    } catch (error) {
      resolve({
        ok: false,
        error: error && error.message ? error.message : 'Print failed.',
      });
    }
  });
});

safeHandle('corra:hardware-open-user-data', async () => {
  try {
    const result = await shell.openPath(app.getPath('userData'));
    if (result) return { ok: false, error: result };
    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      error: error && error.message ? error.message : 'Failed to open userData.',
    };
  }
});

safeHandle('corra:kiosk-set-fullscreen', async (_event, payload) => {
  const win = getActiveWindow();
  if (!win) return { ok: false, error: 'No active BrowserWindow.' };

  win.setFullScreen(Boolean(payload && payload.enabled));

  return {
    ok: true,
    isFullScreen: win.isFullScreen(),
    isKiosk: win.isKiosk(),
  };
});

safeHandle('corra:kiosk-set-kiosk', async (_event, payload) => {
  const win = getActiveWindow();
  if (!win) return { ok: false, error: 'No active BrowserWindow.' };

  win.setKiosk(Boolean(payload && payload.enabled));

  return {
    ok: true,
    isFullScreen: win.isFullScreen(),
    isKiosk: win.isKiosk(),
  };
});

console.log('[Corra] hardware diagnostics IPC registered.');
CJS

cat > apps/desktop-electron/corra-hardware-preload.cjs <<'CJS'
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('corraHardware', {
  getRuntimeInfo: () => ipcRenderer.invoke('corra:hardware-runtime-info'),
  listPrinters: () => ipcRenderer.invoke('corra:hardware-list-printers'),
  printCurrentPage: (payload) => ipcRenderer.invoke('corra:hardware-print-current-page', payload || {}),
  openUserData: () => ipcRenderer.invoke('corra:hardware-open-user-data'),
  setFullscreen: (enabled) =>
    ipcRenderer.invoke('corra:kiosk-set-fullscreen', { enabled: Boolean(enabled) }),
  setKiosk: (enabled) =>
    ipcRenderer.invoke('corra:kiosk-set-kiosk', { enabled: Boolean(enabled) }),
});
CJS

cat > apps/booth-ui/src/booth/booth-hardware-types.ts <<'TS'
export type BoothHardwareRuntimeInfo = {
  ok: boolean;
  appVersion?: string;
  platform?: string;
  arch?: string;
  node?: string;
  electron?: string;
  chrome?: string;
  hostname?: string;
  username?: string;
  userDataPath?: string;
  tempPath?: string;
  timestamp?: string;
  error?: string;
};

export type BoothHardwarePrinterInfo = {
  name: string;
  displayName: string;
  description?: string;
  status?: number;
  isDefault?: boolean;
  options?: Record<string, unknown>;
};

export type BoothHardwarePrinterListResult = {
  ok: boolean;
  printers: BoothHardwarePrinterInfo[];
  error?: string;
};

export type BoothHardwarePrintPayload = {
  printerName?: string;
  silent?: boolean;
  copies?: number;
  pageSize?: string | Record<string, unknown>;
};

export type BoothHardwareActionResult = {
  ok: boolean;
  error?: string;
  isFullScreen?: boolean;
  isKiosk?: boolean;
};

export type BoothHardwareTestStatus =
  | 'untested'
  | 'passed'
  | 'warning'
  | 'failed';

export type BoothHardwareTestRecord = {
  id: string;
  label: string;
  status: BoothHardwareTestStatus;
  message?: string;
  updatedAt: string;
};
TS

cat > apps/booth-ui/src/booth/booth-hardware-api.ts <<'TS'
import type {
  BoothHardwareActionResult,
  BoothHardwarePrinterListResult,
  BoothHardwarePrintPayload,
  BoothHardwareRuntimeInfo,
} from './booth-hardware-types';

declare global {
  interface Window {
    corraHardware?: {
      getRuntimeInfo: () => Promise<BoothHardwareRuntimeInfo>;
      listPrinters: () => Promise<BoothHardwarePrinterListResult>;
      printCurrentPage: (
        payload?: BoothHardwarePrintPayload,
      ) => Promise<BoothHardwareActionResult>;
      openUserData: () => Promise<BoothHardwareActionResult>;
      setFullscreen: (enabled: boolean) => Promise<BoothHardwareActionResult>;
      setKiosk: (enabled: boolean) => Promise<BoothHardwareActionResult>;
    };
  }
}

export function isCorraHardwareBridgeAvailable() {
  return typeof window !== 'undefined' && Boolean(window.corraHardware);
}

export async function getBoothHardwareRuntimeInfo() {
  if (!window.corraHardware) {
    return {
      ok: false,
      error: 'Electron hardware bridge is not available. Run inside Electron.',
    };
  }

  return window.corraHardware.getRuntimeInfo();
}

export async function listBoothHardwarePrinters() {
  if (!window.corraHardware) {
    return {
      ok: false,
      printers: [],
      error: 'Electron hardware bridge is not available. Run inside Electron.',
    };
  }

  return window.corraHardware.listPrinters();
}

export async function printBoothCurrentPage(payload?: BoothHardwarePrintPayload) {
  if (!window.corraHardware) {
    return {
      ok: false,
      error: 'Electron hardware bridge is not available. Run inside Electron.',
    };
  }

  return window.corraHardware.printCurrentPage(payload);
}

export async function openBoothUserDataPath() {
  if (!window.corraHardware) {
    return {
      ok: false,
      error: 'Electron hardware bridge is not available. Run inside Electron.',
    };
  }

  return window.corraHardware.openUserData();
}

export async function setBoothFullscreen(enabled: boolean) {
  if (!window.corraHardware) {
    return {
      ok: false,
      error: 'Electron hardware bridge is not available. Run inside Electron.',
    };
  }

  return window.corraHardware.setFullscreen(enabled);
}

export async function setBoothKiosk(enabled: boolean) {
  if (!window.corraHardware) {
    return {
      ok: false,
      error: 'Electron hardware bridge is not available. Run inside Electron.',
    };
  }

  return window.corraHardware.setKiosk(enabled);
}
TS

cat > apps/booth-ui/src/booth/booth-hardware-test-storage.ts <<'TS'
import type {
  BoothHardwareTestRecord,
  BoothHardwareTestStatus,
} from './booth-hardware-types';

const HARDWARE_TEST_KEY = 'corra.booth.hardware.tests.v1';

function makeId(label: string) {
  return `hardware-test-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
}

export function loadBoothHardwareTestRecords(): BoothHardwareTestRecord[] {
  if (typeof window === 'undefined') return [];

  try {
    const raw = window.localStorage.getItem(HARDWARE_TEST_KEY);
    if (!raw) return [];

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed.filter((record) => record && typeof record.id === 'string');
  } catch {
    return [];
  }
}

export function saveBoothHardwareTestRecords(records: BoothHardwareTestRecord[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(HARDWARE_TEST_KEY, JSON.stringify(records));
}

export function upsertBoothHardwareTestRecord(input: {
  label: string;
  status: BoothHardwareTestStatus;
  message?: string;
}) {
  const records = loadBoothHardwareTestRecords();
  const id = makeId(input.label);
  const nextRecord: BoothHardwareTestRecord = {
    id,
    label: input.label,
    status: input.status,
    message: input.message,
    updatedAt: new Date().toISOString(),
  };

  const nextRecords = [
    ...records.filter((record) => record.id !== id),
    nextRecord,
  ];

  saveBoothHardwareTestRecords(nextRecords);
  return nextRecord;
}

export function clearBoothHardwareTestRecords() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(HARDWARE_TEST_KEY);
}
TS

cat > apps/booth-ui/src/booth/BoothHardwareDiagnosticsPanel.tsx <<'TSX'
import React, { useState } from 'react';
import {
  getBoothHardwareRuntimeInfo,
  isCorraHardwareBridgeAvailable,
  openBoothUserDataPath,
} from './booth-hardware-api';
import type { BoothHardwareRuntimeInfo } from './booth-hardware-types';
import { upsertBoothHardwareTestRecord } from './booth-hardware-test-storage';

export function BoothHardwareDiagnosticsPanel() {
  const [runtime, setRuntime] = useState<BoothHardwareRuntimeInfo | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const runDiagnostics = async () => {
    setMessage('');
    setError('');

    const result = await getBoothHardwareRuntimeInfo();
    setRuntime(result);

    upsertBoothHardwareTestRecord({
      label: 'Electron runtime bridge',
      status: result.ok ? 'passed' : 'failed',
      message: result.ok ? 'Hardware bridge available.' : result.error,
    });

    if (result.ok) setMessage('Runtime diagnostics passed.');
    else setError(result.error || 'Runtime diagnostics failed.');
  };

  const openUserData = async () => {
    const result = await openBoothUserDataPath();

    if (result.ok) setMessage('Opened userData folder.');
    else setError(result.error || 'Failed to open userData folder.');
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Hardware Diagnostics
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Electron bridge, runtime, userData path, platform info.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void runDiagnostics()}
            className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"
          >
            Run
          </button>

          <button
            type="button"
            onClick={() => void openUserData()}
            className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white"
          >
            Open userData
          </button>
        </div>
      </div>

      <div className="mt-4 rounded-2xl bg-white/10 p-3 text-xs font-bold text-white/60">
        Bridge: {isCorraHardwareBridgeAvailable() ? 'Available' : 'Unavailable'}
      </div>

      {message && (
        <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">
          {message}
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">
          {error}
        </div>
      )}

      {runtime && (
        <pre className="mt-4 max-h-72 overflow-auto rounded-2xl bg-black/40 p-3 text-[11px] font-bold text-white/60">
          {JSON.stringify(runtime, null, 2)}
        </pre>
      )}
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothPrinterHardwareTestPanel.tsx <<'TSX'
import React, { useState } from 'react';
import {
  listBoothHardwarePrinters,
  printBoothCurrentPage,
} from './booth-hardware-api';
import type { BoothHardwarePrinterInfo } from './booth-hardware-types';
import { upsertBoothHardwareTestRecord } from './booth-hardware-test-storage';

export function BoothPrinterHardwareTestPanel() {
  const [printers, setPrinters] = useState<BoothHardwarePrinterInfo[]>([]);
  const [selectedPrinter, setSelectedPrinter] = useState('');
  const [silent, setSilent] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const refreshPrinters = async () => {
    setMessage('');
    setError('');

    const result = await listBoothHardwarePrinters();
    setPrinters(result.printers);

    if (result.ok) {
      const defaultPrinter = result.printers.find((printer) => printer.isDefault);
      setSelectedPrinter((current) => current || defaultPrinter?.name || result.printers[0]?.name || '');

      upsertBoothHardwareTestRecord({
        label: 'Printer discovery',
        status: result.printers.length > 0 ? 'passed' : 'warning',
        message:
          result.printers.length > 0
            ? `${result.printers.length} printer(s) detected.`
            : 'No printer detected.',
      });

      setMessage(`${result.printers.length} printer(s) detected.`);
    } else {
      upsertBoothHardwareTestRecord({
        label: 'Printer discovery',
        status: 'failed',
        message: result.error,
      });

      setError(result.error || 'Failed to list printers.');
    }
  };

  const runPrintTest = async () => {
    setMessage('');
    setError('');

    const result = await printBoothCurrentPage({
      printerName: selectedPrinter || undefined,
      silent,
      copies: 1,
    });

    upsertBoothHardwareTestRecord({
      label: 'Printer test',
      status: result.ok ? 'passed' : 'failed',
      message: result.ok ? 'Print command accepted.' : result.error,
    });

    if (result.ok) setMessage('Print command accepted.');
    else setError(result.error || 'Print test failed.');
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Printer Hardware Test
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Detect printers and send a print-current-page test.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void refreshPrinters()}
          className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"
        >
          Refresh Printers
        </button>
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_auto]">
        <select
          value={selectedPrinter}
          onChange={(event) => setSelectedPrinter(event.target.value)}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
        >
          <option value="">Default printer / prompt</option>
          {printers.map((printer) => (
            <option key={printer.name} value={printer.name}>
              {printer.displayName || printer.name}
              {printer.isDefault ? ' (default)' : ''}
            </option>
          ))}
        </select>

        <button
          type="button"
          onClick={() => void runPrintTest()}
          className="rounded-2xl border border-white/15 bg-white/10 px-3 py-3 text-xs font-black text-white"
        >
          Print Test
        </button>
      </div>

      <label className="mt-3 flex items-center gap-2 text-xs font-bold text-white/60">
        <input
          type="checkbox"
          checked={silent}
          onChange={(event) => setSilent(event.target.checked)}
        />
        Silent print if supported
      </label>

      <div className="mt-4 grid gap-2">
        {printers.map((printer) => (
          <div key={printer.name} className="rounded-2xl bg-white/10 p-3">
            <p className="text-xs font-black uppercase text-white">
              {printer.displayName || printer.name}
            </p>
            <p className="mt-1 text-[11px] font-bold text-white/45">
              name={printer.name} · status={printer.status ?? 0}
              {printer.isDefault ? ' · default' : ''}
            </p>
          </div>
        ))}
      </div>

      {message && (
        <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">
          {message}
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">
          {error}
        </div>
      )}
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothCameraHardwareTestPanel.tsx <<'TSX'
import React, { useRef, useState } from 'react';
import { upsertBoothHardwareTestRecord } from './booth-hardware-test-storage';

type CameraDevice = {
  deviceId: string;
  label: string;
  kind: string;
};

export function BoothCameraHardwareTestPanel() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const currentStreamRef = useRef<MediaStream | null>(null);
  const [devices, setDevices] = useState<CameraDevice[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const stopCurrentStream = () => {
    currentStreamRef.current?.getTracks().forEach((track) => track.stop());
    currentStreamRef.current = null;
  };

  const refreshCameras = async () => {
    setMessage('');
    setError('');

    try {
      await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      const allDevices = await navigator.mediaDevices.enumerateDevices();
      const cameras = allDevices
        .filter((device) => device.kind === 'videoinput')
        .map((device, index) => ({
          deviceId: device.deviceId,
          kind: device.kind,
          label: device.label || `Camera ${index + 1}`,
        }));

      setDevices(cameras);
      setSelectedDeviceId((current) => current || cameras[0]?.deviceId || '');

      upsertBoothHardwareTestRecord({
        label: 'Camera discovery',
        status: cameras.length > 0 ? 'passed' : 'failed',
        message:
          cameras.length > 0
            ? `${cameras.length} camera(s) detected.`
            : 'No camera detected.',
      });

      setMessage(`${cameras.length} camera(s) detected.`);
    } catch (caughtError) {
      const nextError =
        caughtError instanceof Error
          ? caughtError.message
          : 'Failed to access camera.';

      upsertBoothHardwareTestRecord({
        label: 'Camera discovery',
        status: 'failed',
        message: nextError,
      });

      setError(nextError);
    }
  };

  const startPreview = async () => {
    setMessage('');
    setError('');

    try {
      stopCurrentStream();

      const stream = await navigator.mediaDevices.getUserMedia({
        video: selectedDeviceId
          ? { deviceId: { exact: selectedDeviceId } }
          : true,
        audio: false,
      });

      currentStreamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      upsertBoothHardwareTestRecord({
        label: 'Camera preview',
        status: 'passed',
        message: 'Camera preview started.',
      });

      setMessage('Camera preview started.');
    } catch (caughtError) {
      const nextError =
        caughtError instanceof Error
          ? caughtError.message
          : 'Failed to start camera preview.';

      upsertBoothHardwareTestRecord({
        label: 'Camera preview',
        status: 'failed',
        message: nextError,
      });

      setError(nextError);
    }
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Camera Hardware Test
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Detect cameras and start a live preview.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void refreshCameras()}
            className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"
          >
            Refresh Cameras
          </button>

          <button
            type="button"
            onClick={stopCurrentStream}
            className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white"
          >
            Stop
          </button>
        </div>
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_auto]">
        <select
          value={selectedDeviceId}
          onChange={(event) => setSelectedDeviceId(event.target.value)}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
        >
          <option value="">Default camera</option>
          {devices.map((device) => (
            <option key={device.deviceId} value={device.deviceId}>
              {device.label}
            </option>
          ))}
        </select>

        <button
          type="button"
          onClick={() => void startPreview()}
          className="rounded-2xl border border-white/15 bg-white/10 px-3 py-3 text-xs font-black text-white"
        >
          Start Preview
        </button>
      </div>

      <div className="mt-4 overflow-hidden rounded-3xl border border-white/10 bg-black">
        <video
          ref={videoRef}
          muted
          playsInline
          className="aspect-video w-full object-contain"
        />
      </div>

      {message && (
        <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">
          {message}
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">
          {error}
        </div>
      )}
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothKioskHardwareTestPanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import {
  setBoothFullscreen,
  setBoothKiosk,
} from './booth-hardware-api';
import {
  loadBoothHardwareTestRecords,
  upsertBoothHardwareTestRecord,
} from './booth-hardware-test-storage';

export function BoothKioskHardwareTestPanel() {
  const [records, setRecords] = useState(() => loadBoothHardwareTestRecords());
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const passedCount = useMemo(() => {
    return records.filter((record) => record.status === 'passed').length;
  }, [records]);

  const runAction = async (
    label: string,
    action: () => Promise<{ ok: boolean; error?: string }>,
  ) => {
    setMessage('');
    setError('');

    const result = await action();

    upsertBoothHardwareTestRecord({
      label,
      status: result.ok ? 'passed' : 'failed',
      message: result.ok ? `${label} succeeded.` : result.error,
    });

    setRecords(loadBoothHardwareTestRecords());

    if (result.ok) setMessage(`${label} succeeded.`);
    else setError(result.error || `${label} failed.`);
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Kiosk Runtime Test
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Fullscreen/kiosk mode controls and hardware readiness checklist.
          </p>
        </div>

        <div className="rounded-2xl bg-white/10 px-3 py-2 text-xs font-black text-white">
          {passedCount}/{records.length} passed
        </div>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        <button
          type="button"
          onClick={() => void runAction('Fullscreen on', () => setBoothFullscreen(true))}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
        >
          Fullscreen On
        </button>

        <button
          type="button"
          onClick={() => void runAction('Fullscreen off', () => setBoothFullscreen(false))}
          className="rounded-2xl border border-white/15 bg-white/10 px-3 py-3 text-xs font-black text-white"
        >
          Fullscreen Off
        </button>

        <button
          type="button"
          onClick={() => void runAction('Kiosk on', () => setBoothKiosk(true))}
          className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-950"
        >
          Kiosk On
        </button>

        <button
          type="button"
          onClick={() => void runAction('Kiosk off', () => setBoothKiosk(false))}
          className="rounded-2xl border border-white/15 bg-white/10 px-3 py-3 text-xs font-black text-white"
        >
          Kiosk Off
        </button>
      </div>

      {message && (
        <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">
          {message}
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">
          {error}
        </div>
      )}

      <div className="mt-4 grid gap-2">
        {records.map((record) => (
          <div key={record.id} className="rounded-2xl bg-white/10 p-3">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-white">
              {record.label} · {record.status}
            </p>
            {record.message && (
              <p className="mt-1 text-[11px] font-bold text-white/50">
                {record.message}
              </p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothProductionReadinessPanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import {
  clearBoothHardwareTestRecords,
  loadBoothHardwareTestRecords,
} from './booth-hardware-test-storage';

const REQUIRED_TESTS = [
  'Electron runtime bridge',
  'Printer discovery',
  'Printer test',
  'Camera discovery',
  'Camera preview',
  'Fullscreen on',
  'Kiosk on',
];

export function BoothProductionReadinessPanel() {
  const [records, setRecords] = useState(() => loadBoothHardwareTestRecords());

  const summary = useMemo(() => {
    const passedLabels = new Set(
      records
        .filter((record) => record.status === 'passed')
        .map((record) => record.label),
    );

    const missing = REQUIRED_TESTS.filter((label) => !passedLabels.has(label));

    return {
      required: REQUIRED_TESTS.length,
      passed: REQUIRED_TESTS.length - missing.length,
      missing,
      ready: missing.length === 0,
    };
  }, [records]);

  const refresh = () => setRecords(loadBoothHardwareTestRecords());

  const clear = () => {
    clearBoothHardwareTestRecords();
    refresh();
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Production Readiness
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Final hardware checklist before booth goes live.
          </p>
        </div>

        <div
          className={`rounded-2xl px-3 py-2 text-xs font-black ${
            summary.ready
              ? 'bg-emerald-500/20 text-emerald-100'
              : 'bg-amber-500/20 text-amber-100'
          }`}
        >
          {summary.ready ? 'READY' : 'NOT READY'} · {summary.passed}/{summary.required}
        </div>
      </div>

      <div className="mt-4 grid gap-2">
        {REQUIRED_TESTS.map((label) => {
          const record = records.find((item) => item.label === label);
          const passed = record?.status === 'passed';

          return (
            <div
              key={label}
              className={`rounded-2xl p-3 ${
                passed ? 'bg-emerald-500/20' : 'bg-white/10'
              }`}
            >
              <p className="text-xs font-black uppercase tracking-[0.14em] text-white">
                {passed ? '✅' : '⬜'} {label}
              </p>
              {record?.message && (
                <p className="mt-1 text-[11px] font-bold text-white/50">
                  {record.message}
                </p>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={refresh}
          className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"
        >
          Refresh
        </button>

        <button
          type="button"
          onClick={clear}
          className="rounded-2xl border border-red-300/30 bg-red-500/20 px-3 py-2 text-xs font-black text-red-100"
        >
          Clear Test Records
        </button>
      </div>

      {!summary.ready && (
        <div className="mt-4 rounded-2xl bg-amber-500/20 p-3 text-xs font-bold text-amber-100">
          Missing: {summary.missing.join(', ')}
        </div>
      )}
    </section>
  );
}
TSX

python - <<'PY'
from pathlib import Path

path = Path("apps/booth-ui/src/booth/BoothCustomerScreen.tsx")
if not path.exists():
    raise SystemExit("BoothCustomerScreen.tsx not found")

text = path.read_text()

imports = [
    "import { BoothHardwareDiagnosticsPanel } from './BoothHardwareDiagnosticsPanel';",
    "import { BoothPrinterHardwareTestPanel } from './BoothPrinterHardwareTestPanel';",
    "import { BoothCameraHardwareTestPanel } from './BoothCameraHardwareTestPanel';",
    "import { BoothKioskHardwareTestPanel } from './BoothKioskHardwareTestPanel';",
    "import { BoothProductionReadinessPanel } from './BoothProductionReadinessPanel';",
]

for line in imports:
    if line not in text:
        lines = text.splitlines()
        insert_at = 0
        for index, existing in enumerate(lines):
            if existing.startswith("import "):
                insert_at = index + 1
        lines.insert(insert_at, line)
        text = "\n".join(lines) + "\n"

panel_block = """
            <div className="mt-4">
              <BoothHardwareDiagnosticsPanel />
            </div>

            <div className="mt-4">
              <BoothPrinterHardwareTestPanel />
            </div>

            <div className="mt-4">
              <BoothCameraHardwareTestPanel />
            </div>

            <div className="mt-4">
              <BoothKioskHardwareTestPanel />
            </div>

            <div className="mt-4">
              <BoothProductionReadinessPanel />
            </div>"""

if "<BoothProductionReadinessPanel />" not in text:
    markers = [
        """            <div className="mt-4">
              <BoothCloudCleanupPanel />
            </div>""",
        """            <div className="mt-4">
              <BoothDiskRetentionCleanupPanel />
            </div>""",
        """            <div className="mt-4">
              <BoothLocalAssetsPanel />
            </div>""",
        """            <div className="mt-4">
              <BoothLifecycleDebugPanel />
            </div>""",
    ]

    patched = False
    for marker in markers:
        if marker in text:
            text = text.replace(marker, marker + "\n" + panel_block, 1)
            patched = True
            break

    if not patched:
        print("WARN: No dev panel marker found. Hardware panels not inserted.")

path.write_text(text)
print("PATCH:", path)
PY

cat >> apps/booth-ui/src/booth/index.ts <<'TS'
export * from './booth-hardware-types';
export * from './booth-hardware-api';
export * from './booth-hardware-test-storage';
export * from './BoothHardwareDiagnosticsPanel';
export * from './BoothPrinterHardwareTestPanel';
export * from './BoothCameraHardwareTestPanel';
export * from './BoothKioskHardwareTestPanel';
export * from './BoothProductionReadinessPanel';
TS

python - <<'PY'
from pathlib import Path
path = Path("apps/booth-ui/src/booth/index.ts")
lines = path.read_text().splitlines()
seen = set()
out = []
for line in lines:
    if line.startswith("export * from "):
        if line in seen:
            continue
        seen.add(line)
    out.append(line)
path.write_text("\n".join(out) + "\n")
PY

cat > scripts/patch-9f-electron-hardware-bridge.sh <<'PATCH'
#!/usr/bin/env bash
set -euo pipefail

MAIN_REQUIRE="require('./corra-hardware-diagnostics.cjs');"
PRELOAD_REQUIRE="require('./corra-hardware-preload.cjs');"

patch_require_once() {
  local file="$1"
  local line="$2"

  if [ ! -f "$file" ]; then
    echo "SKIP missing: $file"
    return
  fi

  if grep -qF "$line" "$file"; then
    echo "OK already patched: $file"
    return
  fi

  cp "$file" "$file.bak.$(date +%Y%m%d%H%M%S)"

  python - "$file" "$line" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
line = sys.argv[2]
text = path.read_text()

if text.startswith("#!"):
    parts = text.split("\n", 1)
    text = parts[0] + "\n" + line + "\n" + (parts[1] if len(parts) > 1 else "")
else:
    text = line + "\n" + text

path.write_text(text)
PY

  echo "PATCHED: $file"
}

patch_require_once "apps/desktop-electron/main.cjs" "$MAIN_REQUIRE"
patch_require_once "apps/desktop-electron/index.cjs" "$MAIN_REQUIRE"
patch_require_once "apps/desktop-electron/preload.cjs" "$PRELOAD_REQUIRE"

echo ""
grep -R \
  --exclude-dir=node_modules \
  --exclude-dir=dist \
  --exclude-dir=.vite \
  "corra-hardware-diagnostics\|corra-hardware-preload" \
  -n apps/desktop-electron || true
PATCH

chmod +x scripts/patch-9f-electron-hardware-bridge.sh
./scripts/patch-9f-electron-hardware-bridge.sh

cat > docs/phase-9f-printer-kiosk-hardware-checklist.md <<'MD'
# Phase 9F — Printer / Kiosk Hardware Testing Checklist

Status: code scaffold complete after typecheck passes.

Completed:
- 9F1 Electron hardware diagnostics IPC
- 9F2 Electron preload hardware bridge
- 9F3 Frontend hardware API/storage
- 9F4 Runtime diagnostics panel
- 9F5 Printer discovery and print test panel
- 9F6 Camera discovery and preview test panel
- 9F7 Kiosk fullscreen/kiosk controls
- 9F8 Production readiness panel
- 9F9 Booth dev integration
- 9F10 Export wiring
- 9F11 Electron CJS bridge patch
- 9F12 Docs/checker

Important:
- Browser Vite cannot access `window.corraHardware`.
- Hardware bridge only works inside Electron.
- Print test uses Electron `webContents.print`.
- Silent print may depend on OS/printer driver support.

Test:
```txt
?mode=booth&dev=1
```

Recommended run order:
1. Hardware Diagnostics → Run
2. Printer Hardware Test → Refresh Printers
3. Printer Hardware Test → Print Test
4. Camera Hardware Test → Refresh Cameras
5. Camera Hardware Test → Start Preview
6. Kiosk Runtime Test → Fullscreen On
7. Kiosk Runtime Test → Kiosk On
8. Production Readiness → Refresh
MD

cat > docs/phase-9f-status.md <<'MD'
# Phase 9F Status

9F1 done
9F2 done
9F3 done
9F4 done
9F5 done
9F6 done
9F7 done
9F8 done
9F9 done
9F10 done
9F11 done
9F12 done

Next recommended phase:
- 9G Packaging / Release Candidate
MD

cat > scripts/check-phase-9f-status.sh <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail

f(){ [ -f "$2" ] && echo "✅ $1" || echo "❌ $1"; }

echo "Phase 9F Status"
echo "==============="

f "9F1 hardware IPC" apps/desktop-electron/corra-hardware-diagnostics.cjs
f "9F2 hardware preload" apps/desktop-electron/corra-hardware-preload.cjs
f "9F3 types" apps/booth-ui/src/booth/booth-hardware-types.ts
f "9F3 api" apps/booth-ui/src/booth/booth-hardware-api.ts
f "9F3 storage" apps/booth-ui/src/booth/booth-hardware-test-storage.ts
f "9F4 diagnostics panel" apps/booth-ui/src/booth/BoothHardwareDiagnosticsPanel.tsx
f "9F5 printer panel" apps/booth-ui/src/booth/BoothPrinterHardwareTestPanel.tsx
f "9F6 camera panel" apps/booth-ui/src/booth/BoothCameraHardwareTestPanel.tsx
f "9F7 kiosk panel" apps/booth-ui/src/booth/BoothKioskHardwareTestPanel.tsx
f "9F8 readiness panel" apps/booth-ui/src/booth/BoothProductionReadinessPanel.tsx
f "9F11 patch script" scripts/patch-9f-electron-hardware-bridge.sh
f "9F12 checklist" docs/phase-9f-printer-kiosk-hardware-checklist.md

echo ""
echo "Electron bridge refs:"
grep -R \
  --exclude-dir=node_modules \
  --exclude-dir=dist \
  --exclude-dir=.vite \
  "corra-hardware-diagnostics\|corra-hardware-preload" \
  -n apps/desktop-electron || true

echo ""
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
CHECK

chmod +x scripts/check-phase-9f-status.sh

echo ""
echo "Phase 9F full code applied."
echo "Next run:"
echo "pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false"
echo "./scripts/check-phase-9f-status.sh"
echo ""
echo "Then test in Electron, not only browser Vite."
