#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/booth-ui/src/booth docs scripts

python - <<'PY'
from pathlib import Path

path = Path("apps/booth-ui/src/booth/BoothCustomerScreen.tsx")
text = path.read_text()

imports = [
    "import { BoothCloudUploadHealthPanel } from './BoothCloudUploadHealthPanel';",
    "import { BoothCloudUploadQueuePanel } from './BoothCloudUploadQueuePanel';",
    "import { BoothCloudAssetBrowserPanel } from './BoothCloudAssetBrowserPanel';",
    "import { BoothCloudCleanupPanel } from './BoothCloudCleanupPanel';",
]
for line in imports:
    if line not in text:
        lines = text.splitlines()
        insert_at = 0
        for index, existing in enumerate(lines):
            if existing.startswith("import "):
                insert_at = index + 1
        lines.insert(insert_at, line)
        text = "\n".join(lines) + "\n"

if "<BoothCloudUploadHealthPanel />" not in text:
    marker = """            <div className=\"mt-4\">
              <BoothCloudUploadPanel />
            </div>"""
    addition = marker + """

            <div className=\"mt-4\">
              <BoothCloudUploadHealthPanel />
            </div>

            <div className=\"mt-4\">
              <BoothCloudUploadQueuePanel />
            </div>

            <div className=\"mt-4\">
              <BoothCloudAssetBrowserPanel />
            </div>

            <div className=\"mt-4\">
              <BoothCloudCleanupPanel />
            </div>"""
    if marker in text:
        text = text.replace(marker, addition, 1)
    else:
        print("WARN: BoothCloudUploadPanel marker not found; dev panels not inserted.")

path.write_text(text)
print("PATCH:", path)
PY

python - <<'PY'
from pathlib import Path

path = Path("apps/booth-ui/src/booth/BoothDeliveryStep.tsx")
if not path.exists():
    raise SystemExit(0)
text = path.read_text()
import_line = "import { BoothDeliverySharePanel } from './BoothDeliverySharePanel';"
if import_line not in text:
    lines = text.splitlines()
    insert_at = 0
    for index, existing in enumerate(lines):
        if existing.startswith("import "):
            insert_at = index + 1
    lines.insert(insert_at, import_line)
    text = "\n".join(lines) + "\n"

if "<BoothDeliverySharePanel />" not in text:
    marker = """      </aside>
    </div>
  );"""
    replacement = """      </aside>

      <div className=\"xl:col-span-2\">
        <BoothDeliverySharePanel />
      </div>
    </div>
  );"""
    if marker in text:
        text = text.replace(marker, replacement, 1)
    else:
        print("WARN: Delivery closing marker not found; share panel not inserted.")

path.write_text(text)
print("PATCH:", path)
PY

cat >> apps/booth-ui/src/booth/index.ts <<'TS'
export * from './booth-cloud-refresh-api';
export * from './booth-cloud-delete-api';
export * from './booth-cloud-upload-health';
export * from './booth-cloud-upload-queue-types';
export * from './booth-cloud-upload-queue-storage';
export * from './BoothCloudUploadHealthPanel';
export * from './BoothCloudUploadQueuePanel';
export * from './BoothDeliverySharePanel';
export * from './BoothCloudAssetBrowserPanel';
export * from './BoothCloudCleanupPanel';
TS

python - <<'PY'
from pathlib import Path
path = Path("apps/booth-ui/src/booth/index.ts")
lines = path.read_text().splitlines()
seen = set()
out = []
for line in lines:
    if line.startswith("export * from "):
        if line in seen:
            continue
        seen.add(line)
    out.append(line)
path.write_text("\n".join(out) + "\n")
PY

ENV_FILE="apps/booth-ui/.env.local"
touch "$ENV_FILE"
if ! grep -q "^VITE_REFRESH_BOOTH_SIGNED_URL_URL=" "$ENV_FILE"; then
  cat >> "$ENV_FILE" <<'ENV'

VITE_REFRESH_BOOTH_SIGNED_URL_URL=https://uitnzrstkjvwiojbnpwg.supabase.co/functions/v1/refresh-booth-signed-url
ENV
fi
if ! grep -q "^VITE_DELETE_BOOTH_CLOUD_ASSET_URL=" "$ENV_FILE"; then
  cat >> "$ENV_FILE" <<'ENV'
VITE_DELETE_BOOTH_CLOUD_ASSET_URL=https://uitnzrstkjvwiojbnpwg.supabase.co/functions/v1/delete-booth-cloud-asset
ENV
fi

cat > docs/phase-9c-cloud-upload-hardening-checklist.md <<'MD'
# Phase 9C — Cloud Upload Hardening Checklist

Status: code scaffold complete after typecheck passes.

Completed:
- 9C1 Cloud upload health monitor
- 9C2 Signed URL refresh Edge Function + UI
- 9C3 Upload retry queue
- 9C4 Upload progress / failed upload recovery
- 9C5 Delivery share link + QR
- 9C6 Cloud asset browser
- 9C7 Cloud cleanup tools
- 9C8 Checklist close

Deploy:
```bash
pnpm dlx supabase functions deploy refresh-booth-signed-url --no-verify-jwt
pnpm dlx supabase functions deploy delete-booth-cloud-asset --no-verify-jwt
```
MD

cat > docs/phase-9c-status.md <<'MD'
# Phase 9C Status

9C1 done
9C2 done
9C3 done
9C4 done
9C5 done
9C6 done
9C7 done
9C8 done

Next recommended phase:
- 9D Real Payment Integration
- 9E Electron Disk Persistence
MD

cat > scripts/check-phase-9c-status.sh <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail
f(){ [ -f "$2" ] && echo "✅ $1" || echo "❌ $1"; }
echo "Phase 9C Status"
echo "==============="
f "9C1 health util" apps/booth-ui/src/booth/booth-cloud-upload-health.ts
f "9C1 health panel" apps/booth-ui/src/booth/BoothCloudUploadHealthPanel.tsx
f "9C2 refresh function" supabase/functions/refresh-booth-signed-url/index.ts
f "9C2 refresh api" apps/booth-ui/src/booth/booth-cloud-refresh-api.ts
f "9C3 queue types" apps/booth-ui/src/booth/booth-cloud-upload-queue-types.ts
f "9C3 queue storage" apps/booth-ui/src/booth/booth-cloud-upload-queue-storage.ts
f "9C4 queue panel" apps/booth-ui/src/booth/BoothCloudUploadQueuePanel.tsx
f "9C5 delivery share" apps/booth-ui/src/booth/BoothDeliverySharePanel.tsx
f "9C6 cloud browser" apps/booth-ui/src/booth/BoothCloudAssetBrowserPanel.tsx
f "9C7 cleanup panel" apps/booth-ui/src/booth/BoothCloudCleanupPanel.tsx
f "9C7 delete function" supabase/functions/delete-booth-cloud-asset/index.ts
f "9C8 checklist" docs/phase-9c-cloud-upload-hardening-checklist.md
echo ""
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
CHECK
chmod +x scripts/check-phase-9c-status.sh

echo "9C integration/docs patch written."
