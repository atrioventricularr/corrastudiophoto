# Phase 9D Full — Real Payment Integration

Run from repo root:

```bash
cd /workspaces/corrastudiophoto
bash /mnt/data/phase-9d-full-code/run-phase-9d-full.sh
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
./scripts/check-phase-9d-status.sh
```

Deploy after typecheck is clean:

```bash
pnpm dlx supabase db push
pnpm dlx supabase secrets set MAYAR_API_KEY=your_mayar_api_key
pnpm dlx supabase functions deploy create-mayar-checkout --no-verify-jwt
pnpm dlx supabase functions deploy check-mayar-transaction-status --no-verify-jwt
pnpm dlx supabase functions deploy mayar-payment-webhook --no-verify-jwt
```

Test:

```txt
?mode=booth&dev=1
```

What it adds:

- 9D0 unified booth payment intents table
- 9D1 Mayar checkout create function
- 9D2 Mayar transaction status function
- 9D3 Mayar webhook receiver
- 9D4 frontend payment runtime types/storage/api
- 9D5 runtime test panel
- 9D6 provider diagnostics panel
- 9D7 env entries
- 9D8 docs/checker
