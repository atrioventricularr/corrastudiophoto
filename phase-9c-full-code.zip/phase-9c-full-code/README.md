# Phase 9C Full Code — Cloud Upload Hardening 9C1–9C8

Copy/run from repo root:

```bash
cd /workspaces/corrastudiophoto
bash /mnt/data/phase-9c-full-code/run-phase-9c-full.sh
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
./scripts/check-phase-9c-status.sh
```

Deploy after typecheck is clean:

```bash
pnpm dlx supabase functions deploy refresh-booth-signed-url --no-verify-jwt
pnpm dlx supabase functions deploy delete-booth-cloud-asset --no-verify-jwt
```

Includes:

- 9C1 Cloud Upload Health Monitor
- 9C2 Refresh Signed URL
- 9C3 Upload Retry Queue
- 9C4 Upload Progress + Failed Upload Recovery
- 9C5 Customer Delivery Share Link / QR
- 9C6 Admin Cloud Asset Browser
- 9C7 Cloud Cleanup / Retention Tools
- 9C8 Checklist Close
