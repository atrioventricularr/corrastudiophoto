# Phase 9E Full Code — Electron Disk Persistence

Run from repo root:

```bash
cd /workspaces/corrastudiophoto
bash /mnt/data/phase-9e-full-code/run-phase-9e-full.sh
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
./scripts/check-phase-9e-status.sh
```

Commit after typecheck is clean:

```bash
git add .
git commit -m "feat: add phase 9e electron disk persistence"
git push origin main
```

Includes:

- 9E1 Electron disk IPC module
- 9E2 Preload `window.corraDisk` bridge
- 9E3 Frontend disk API and types
- 9E4 Local disk record registry
- 9E5 Dev/Admin disk persistence panel
- 9E6 Disk file browser + delete
- 9E7 Disk retention cleanup
- 9E8 Delivery save-to-disk panel + docs/checker

Expected output folder inside Electron:

```txt
app.getPath('userData')/corra-booth-output/<sessionId>/<kind>/...
```

Manual fallback if auto-patch cannot find Electron main/preload:

Main process:

```js
const { registerCorraDiskPersistence } = require('./corra-disk-persistence.cjs');
registerCorraDiskPersistence({ ipcMain, app, shell, dialog });
```

Preload:

```js
const { installCorraDiskBridge } = require('./corra-disk-preload.cjs');
installCorraDiskBridge({ contextBridge, ipcRenderer });
```
