#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/booth-ui/src/booth

cat > apps/booth-ui/src/booth/BoothCloudUploadHealthPanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import { getCloudUploadRecordState, summarizeCloudUploadHealth } from './booth-cloud-upload-health';
import { loadBoothCloudUploadRecords, saveBoothCloudUploadRecords } from './booth-cloud-upload-storage';
import { refreshBoothSignedUrl } from './booth-cloud-refresh-api';

export function BoothCloudUploadHealthPanel() {
  const [records, setRecords] = useState(() => loadBoothCloudUploadRecords());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const health = useMemo(() => summarizeCloudUploadHealth(records), [records]);
  const recentRecords = records.slice(-5).reverse();

  const handleRefreshExpiredLinks = async () => {
    setIsRefreshing(true); setMessage(''); setError('');
    try {
      const latest = loadBoothCloudUploadRecords();
      const targets = latest.filter((record) => {
        const state = getCloudUploadRecordState(record);
        return state === 'expired' || state === 'expiring_soon';
      });
      if (targets.length === 0) { setRecords(latest); setMessage('No expired or expiring signed links.'); return; }
      const nextRecords = [...latest];
      for (const target of targets) {
        const refreshed = await refreshBoothSignedUrl(target);
        const index = nextRecords.findIndex((record) => record.id === target.id);
        if (index >= 0) nextRecords[index] = refreshed;
      }
      saveBoothCloudUploadRecords(nextRecords); setRecords(nextRecords); setMessage(`Refreshed ${targets.length} signed link(s).`);
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : 'Failed to refresh signed links.');
    } finally { setIsRefreshing(false); }
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">Cloud Upload Health</p>
          <p className="mt-1 text-sm font-bold text-white/60">Monitor signed URLs and refresh expiring links.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => { setRecords(loadBoothCloudUploadRecords()); setMessage('Records refreshed.'); }} className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white">Refresh</button>
          <button type="button" onClick={() => void handleRefreshExpiredLinks()} disabled={isRefreshing} className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950 disabled:opacity-40">{isRefreshing ? 'Refreshing...' : 'Refresh Expired Links'}</button>
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div className="rounded-2xl bg-white/10 p-3"><p className="text-xs font-black uppercase text-white/40">Total</p><p className="mt-1 text-2xl font-black text-white">{health.total}</p></div>
        <div className="rounded-2xl bg-emerald-500/20 p-3"><p className="text-xs font-black uppercase text-emerald-100">Valid</p><p className="mt-1 text-2xl font-black text-white">{health.valid}</p></div>
        <div className="rounded-2xl bg-amber-500/20 p-3"><p className="text-xs font-black uppercase text-amber-100">Expiring</p><p className="mt-1 text-2xl font-black text-white">{health.expiringSoon}</p></div>
        <div className="rounded-2xl bg-red-500/20 p-3"><p className="text-xs font-black uppercase text-red-100">Expired</p><p className="mt-1 text-2xl font-black text-white">{health.expired}</p></div>
        <div className="rounded-2xl bg-white/10 p-3"><p className="text-xs font-black uppercase text-white/40">Missing</p><p className="mt-1 text-2xl font-black text-white">{health.missingSignedUrl}</p></div>
      </div>

      {message && <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">{message}</div>}
      {error && <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">{error}</div>}

      <div className="mt-4 grid gap-2">
        {recentRecords.length === 0 && <div className="rounded-2xl bg-white/10 p-3 text-xs font-bold text-white/50">No upload records yet.</div>}
        {recentRecords.map((record) => (
          <div key={record.id} className="rounded-2xl bg-white/10 p-3">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.14em] text-white">{record.kind} · {getCloudUploadRecordState(record)}</p>
                <p className="mt-1 break-all text-xs font-bold text-white/60">{record.filename}</p>
                <p className="mt-1 text-[11px] font-bold text-white/40">Expires: {new Date(record.signedUrlExpiresAt).toLocaleString()}</p>
              </div>
              <a href={record.signedUrl} target="_blank" rel="noreferrer" className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950">Open</a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothCloudUploadQueuePanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import { createBoothCloudUploadRecord, uploadBoothLocalAssetToCloud } from './booth-cloud-upload-api';
import { createQueueItemFromAsset, loadBoothCloudUploadQueue, saveBoothCloudUploadQueue, updateQueueItemStatus } from './booth-cloud-upload-queue-storage';
import type { BoothCloudUploadQueueItem } from './booth-cloud-upload-queue-types';
import { loadBoothCloudUploadRecords, saveBoothCloudUploadRecords } from './booth-cloud-upload-storage';
import { useBoothLocalAssets } from './BoothLocalAssetProvider';

export function BoothCloudUploadQueuePanel() {
  const { assets, refreshAssets } = useBoothLocalAssets();
  const [queue, setQueue] = useState(() => loadBoothCloudUploadQueue());
  const [isRunning, setIsRunning] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [progress, setProgress] = useState({ done: 0, total: 0 });

  const counts = useMemo(() => queue.reduce((acc, item) => { acc[item.status] += 1; return acc; }, { pending: 0, uploading: 0, uploaded: 0, failed: 0 }), [queue]);
  const saveQueue = (items: BoothCloudUploadQueueItem[]) => { saveBoothCloudUploadQueue(items); setQueue(items); };

  const enqueueMissingAssets = async () => {
    await refreshAssets();
    const records = loadBoothCloudUploadRecords();
    const uploadedAssetIds = new Set(records.map((record) => record.localAssetId));
    const queuedAssetIds = new Set(queue.map((item) => item.assetId));
    const newItems = assets.filter((asset) => !uploadedAssetIds.has(asset.id)).filter((asset) => !queuedAssetIds.has(asset.id)).map(createQueueItemFromAsset);
    if (newItems.length === 0) { setMessage('No new assets to enqueue.'); return; }
    saveQueue([...queue, ...newItems]); setMessage(`Enqueued ${newItems.length} asset(s).`);
  };

  const runQueue = async () => {
    setIsRunning(true); setMessage(''); setError('');
    try {
      const workingQueue = [...queue];
      const targets = workingQueue.filter((item) => item.status === 'pending' || item.status === 'failed');
      setProgress({ done: 0, total: targets.length });
      if (targets.length === 0) { setMessage('No pending or failed uploads.'); return; }
      let records = loadBoothCloudUploadRecords();
      for (let index = 0; index < targets.length; index += 1) {
        const item = targets[index];
        const itemIndex = workingQueue.findIndex((candidate) => candidate.id === item.id);
        const asset = assets.find((candidate) => candidate.id === item.assetId);
        if (!asset) { if (itemIndex >= 0) workingQueue[itemIndex] = updateQueueItemStatus(item, 'failed', 'Local asset not found.'); saveQueue(workingQueue); continue; }
        if (itemIndex >= 0) { workingQueue[itemIndex] = updateQueueItemStatus(item, 'uploading'); saveQueue(workingQueue); }
        try {
          const result = await uploadBoothLocalAssetToCloud(asset);
          const uploadRecord = createBoothCloudUploadRecord({ asset, result });
          records = [...records, uploadRecord]; saveBoothCloudUploadRecords(records);
          if (itemIndex >= 0) { workingQueue[itemIndex] = updateQueueItemStatus(workingQueue[itemIndex], 'uploaded'); saveQueue(workingQueue); }
        } catch (caughtError) {
          if (itemIndex >= 0) workingQueue[itemIndex] = updateQueueItemStatus(workingQueue[itemIndex], 'failed', caughtError instanceof Error ? caughtError.message : 'Upload failed.');
          saveQueue(workingQueue);
        }
        setProgress({ done: index + 1, total: targets.length });
      }
      setMessage('Upload queue run completed.');
    } catch (caughtError) { setError(caughtError instanceof Error ? caughtError.message : 'Failed to run upload queue.'); }
    finally { setIsRunning(false); }
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div><p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">Upload Retry Queue</p><p className="mt-1 text-sm font-bold text-white/60">Queue assets, retry failed uploads, and track progress.</p></div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => void enqueueMissingAssets()} disabled={isRunning} className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white disabled:opacity-40">Enqueue Missing</button>
          <button type="button" onClick={() => void runQueue()} disabled={isRunning} className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950 disabled:opacity-40">{isRunning ? 'Uploading...' : 'Run Queue'}</button>
          <button type="button" onClick={() => saveQueue([])} disabled={isRunning || queue.length === 0} className="rounded-2xl border border-red-300/30 bg-red-500/20 px-3 py-2 text-xs font-black text-red-100 disabled:opacity-40">Clear</button>
        </div>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-4">
        <div className="rounded-2xl bg-white/10 p-3"><p className="text-xs font-black uppercase text-white/40">Pending</p><p className="mt-1 text-2xl font-black text-white">{counts.pending}</p></div>
        <div className="rounded-2xl bg-blue-500/20 p-3"><p className="text-xs font-black uppercase text-blue-100">Uploading</p><p className="mt-1 text-2xl font-black text-white">{counts.uploading}</p></div>
        <div className="rounded-2xl bg-emerald-500/20 p-3"><p className="text-xs font-black uppercase text-emerald-100">Uploaded</p><p className="mt-1 text-2xl font-black text-white">{counts.uploaded}</p></div>
        <div className="rounded-2xl bg-red-500/20 p-3"><p className="text-xs font-black uppercase text-red-100">Failed</p><p className="mt-1 text-2xl font-black text-white">{counts.failed}</p></div>
      </div>
      {isRunning && <div className="mt-4 rounded-2xl bg-blue-500/20 p-3 text-xs font-bold text-blue-100">Progress: {progress.done} / {progress.total}</div>}
      {message && <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">{message}</div>}
      {error && <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">{error}</div>}
    </section>
  );
}
TSX

echo "9C health and queue panels written."
