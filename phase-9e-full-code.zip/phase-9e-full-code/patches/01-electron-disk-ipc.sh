#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/desktop-electron

cat > apps/desktop-electron/corra-disk-persistence.cjs <<'JS'
const fs = require('fs');
const path = require('path');

function safeSegment(value, fallback = 'item') {
  return String(value || fallback)
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120) || fallback;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function outputRoot(app) {
  const root = path.join(app.getPath('userData'), 'corra-booth-output');
  ensureDir(root);
  return root;
}

function assertInsideRoot(root, targetPath) {
  const resolvedRoot = path.resolve(root);
  const resolvedTarget = path.resolve(targetPath);
  if (!resolvedTarget.startsWith(resolvedRoot)) {
    throw new Error('Unsafe file path outside Corra output root.');
  }
  return resolvedTarget;
}

function parseDataUrl(dataUrl) {
  const match = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(String(dataUrl || ''));
  if (!match) throw new Error('Invalid data URL.');

  const mimeType = match[1] || 'application/octet-stream';
  const isBase64 = Boolean(match[2]);
  const body = match[3] || '';

  return {
    mimeType,
    buffer: isBase64
      ? Buffer.from(body, 'base64')
      : Buffer.from(decodeURIComponent(body), 'utf8'),
  };
}

function inferExtension(filename, mimeType) {
  const ext = path.extname(String(filename || '')).replace('.', '');
  if (ext) return ext;
  if (mimeType === 'image/png') return 'png';
  if (mimeType === 'image/jpeg') return 'jpg';
  if (mimeType === 'image/webp') return 'webp';
  if (mimeType === 'image/gif') return 'gif';
  if (mimeType === 'application/json') return 'json';
  return 'bin';
}

function listFilesRecursive(root, dir, out = []) {
  if (!fs.existsSync(dir)) return out;

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const entryPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      listFilesRecursive(root, entryPath, out);
      continue;
    }

    const stat = fs.statSync(entryPath);
    out.push({
      path: entryPath,
      relativePath: path.relative(root, entryPath),
      filename: entry.name,
      sizeBytes: stat.size,
      modifiedAt: stat.mtime.toISOString(),
    });
  }

  return out;
}

function registerCorraDiskPersistence({ ipcMain, app, shell }) {
  if (!ipcMain || !app) {
    console.warn('[corra-disk] Missing ipcMain/app. Disk persistence skipped.');
    return;
  }

  const handle = (channel, listener) => {
    try {
      ipcMain.removeHandler(channel);
    } catch (_) {}
    ipcMain.handle(channel, listener);
  };

  handle('corra:disk-get-root', async () => ({ ok: true, rootPath: outputRoot(app) }));

  handle('corra:disk-open-output-folder', async (_event, payload = {}) => {
    const root = outputRoot(app);
    const sessionId = safeSegment(payload.sessionId || '');
    const target = sessionId ? path.join(root, sessionId) : root;
    ensureDir(target);
    if (shell && typeof shell.openPath === 'function') {
      const error = await shell.openPath(target);
      if (error) throw new Error(error);
    }
    return { ok: true, path: target };
  });

  handle('corra:disk-save-data-url', async (_event, payload = {}) => {
    const root = outputRoot(app);
    const sessionId = safeSegment(payload.sessionId || 'unknown-session');
    const kind = safeSegment(payload.kind || 'asset');
    const originalName = safeSegment(payload.filename || `${kind}-${Date.now()}`);
    const parsed = parseDataUrl(payload.dataUrl);
    const ext = inferExtension(originalName, parsed.mimeType);
    const baseName = path.basename(originalName, path.extname(originalName));
    const filename = `${safeSegment(baseName)}-${Date.now()}.${ext}`;
    const dir = assertInsideRoot(root, path.join(root, sessionId, kind));
    ensureDir(dir);

    const filePath = assertInsideRoot(root, path.join(dir, filename));
    fs.writeFileSync(filePath, parsed.buffer);

    const stat = fs.statSync(filePath);
    const record = {
      ok: true,
      id: `disk-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      sessionId,
      kind,
      filename,
      mimeType: parsed.mimeType,
      sizeBytes: stat.size,
      absolutePath: filePath,
      relativePath: path.relative(root, filePath),
      savedAt: new Date().toISOString(),
      metadata: payload.metadata || {},
    };

    fs.writeFileSync(`${filePath}.meta.json`, JSON.stringify(record, null, 2));
    return record;
  });

  handle('corra:disk-save-text-file', async (_event, payload = {}) => {
    const root = outputRoot(app);
    const sessionId = safeSegment(payload.sessionId || 'unknown-session');
    const kind = safeSegment(payload.kind || 'manifest');
    const filename = safeSegment(payload.filename || `${kind}-${Date.now()}.json`);
    const dir = assertInsideRoot(root, path.join(root, sessionId, kind));
    ensureDir(dir);

    const filePath = assertInsideRoot(root, path.join(dir, filename));
    fs.writeFileSync(filePath, String(payload.text || ''), 'utf8');
    const stat = fs.statSync(filePath);

    return {
      ok: true,
      id: `disk-text-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      sessionId,
      kind,
      filename,
      mimeType: payload.mimeType || 'text/plain',
      sizeBytes: stat.size,
      absolutePath: filePath,
      relativePath: path.relative(root, filePath),
      savedAt: new Date().toISOString(),
      metadata: payload.metadata || {},
    };
  });

  handle('corra:disk-list-session-files', async (_event, payload = {}) => {
    const root = outputRoot(app);
    const sessionId = safeSegment(payload.sessionId || '');
    const target = sessionId ? path.join(root, sessionId) : root;
    assertInsideRoot(root, target);
    return { ok: true, rootPath: root, files: listFilesRecursive(root, target).slice(-1000) };
  });

  handle('corra:disk-delete-file', async (_event, payload = {}) => {
    const root = outputRoot(app);
    const target = assertInsideRoot(root, path.join(root, String(payload.relativePath || '')));
    if (fs.existsSync(target)) fs.unlinkSync(target);
    const metaPath = `${target}.meta.json`;
    if (fs.existsSync(metaPath)) fs.unlinkSync(metaPath);
    return { ok: true, relativePath: path.relative(root, target) };
  });

  handle('corra:disk-cleanup-older-than-days', async (_event, payload = {}) => {
    const root = outputRoot(app);
    const days = Math.max(1, Number(payload.days || 30));
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    const files = listFilesRecursive(root, root);
    let deleted = 0;

    for (const file of files) {
      if (new Date(file.modifiedAt).getTime() < cutoff) {
        const target = assertInsideRoot(root, file.path);
        if (fs.existsSync(target)) {
          fs.unlinkSync(target);
          deleted += 1;
        }
      }
    }

    return { ok: true, deletedCount: deleted, days };
  });

  console.log('[corra-disk] Disk persistence IPC registered.');
}

module.exports = { registerCorraDiskPersistence };
JS

cat > apps/desktop-electron/corra-disk-preload.cjs <<'JS'
function installCorraDiskBridge({ contextBridge, ipcRenderer }) {
  if (!contextBridge || !ipcRenderer) {
    console.warn('[corra-disk] Missing contextBridge/ipcRenderer.');
    return;
  }

  contextBridge.exposeInMainWorld('corraDisk', {
    getRoot: () => ipcRenderer.invoke('corra:disk-get-root'),
    openOutputFolder: (payload) => ipcRenderer.invoke('corra:disk-open-output-folder', payload),
    saveDataUrl: (payload) => ipcRenderer.invoke('corra:disk-save-data-url', payload),
    saveTextFile: (payload) => ipcRenderer.invoke('corra:disk-save-text-file', payload),
    listSessionFiles: (payload) => ipcRenderer.invoke('corra:disk-list-session-files', payload),
    deleteFile: (payload) => ipcRenderer.invoke('corra:disk-delete-file', payload),
    cleanupOlderThanDays: (payload) => ipcRenderer.invoke('corra:disk-cleanup-older-than-days', payload),
  });
}

module.exports = { installCorraDiskBridge };
JS

python - <<'PY'
from pathlib import Path
import os

root = Path('apps/desktop-electron')
main_candidates = [
    root/'main.cjs', root/'main.js', root/'index.cjs', root/'index.js',
    root/'src/main.cjs', root/'src/main.js', root/'src/main.ts',
]
preload_candidates = [
    root/'preload.cjs', root/'preload.js', root/'src/preload.cjs',
    root/'src/preload.js', root/'src/preload.ts',
]

def rel_require(from_file: Path, to_file: Path):
    rel = os.path.relpath(to_file, start=from_file.parent).replace('\\', '/')
    if not rel.startswith('.'):
        rel = './' + rel
    return rel

for path in main_candidates:
    if path.exists():
        text = path.read_text()
        if 'registerCorraDiskPersistence' not in text:
            req = rel_require(path, root/'corra-disk-persistence.cjs')
            patch = f"""
try {{
  const {{ registerCorraDiskPersistence }} = require('{req}');
  registerCorraDiskPersistence({{ ipcMain, app, shell, dialog }});
}} catch (error) {{
  console.error('[corra-disk] Failed to register disk persistence:', error);
}}
"""
            insert_at = len(text)
            text = text.rstrip() + "\n" + patch + "\n"
            path.write_text(text)
            print('PATCH main:', path)
        break
else:
    print('WARN: Electron main file not found. Manually require apps/desktop-electron/corra-disk-persistence.cjs from your main process.')

for path in preload_candidates:
    if path.exists():
        text = path.read_text()
        if 'installCorraDiskBridge' not in text:
            req = rel_require(path, root/'corra-disk-preload.cjs')
            patch = f"""
try {{
  const {{ installCorraDiskBridge }} = require('{req}');
  installCorraDiskBridge({{ contextBridge, ipcRenderer }});
}} catch (error) {{
  console.error('[corra-disk] Failed to install disk bridge:', error);
}}
"""
            text = text.rstrip() + "\n" + patch + "\n"
            path.write_text(text)
            print('PATCH preload:', path)
        break
else:
    print('WARN: Electron preload file not found. Manually require apps/desktop-electron/corra-disk-preload.cjs from preload.')
PY

echo "9E1 Electron disk IPC files written."
