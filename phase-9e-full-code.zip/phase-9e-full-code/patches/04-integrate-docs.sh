#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/booth-ui/src/booth docs scripts

python - <<'PY'
from pathlib import Path

path = Path('apps/booth-ui/src/booth/BoothCustomerScreen.tsx')
if path.exists():
    text = path.read_text()
    imports = [
        "import { BoothDiskPersistencePanel } from './BoothDiskPersistencePanel';",
        "import { BoothDiskBrowserPanel } from './BoothDiskBrowserPanel';",
        "import { BoothDiskRetentionPanel } from './BoothDiskRetentionPanel';",
    ]
    for line in imports:
        if line not in text:
            lines = text.splitlines()
            insert_at = 0
            for index, existing in enumerate(lines):
                if existing.startswith('import '):
                    insert_at = index + 1
            lines.insert(insert_at, line)
            text = '\n'.join(lines) + '\n'

    if '<BoothDiskPersistencePanel />' not in text:
        markers = [
            """            <div className=\"mt-4\">\n              <BoothLocalAssetsPanel />\n            </div>""",
            """            <div className=\"mt-4\">\n              <BoothCloudUploadPanel />\n            </div>""",
            """            <BoothLifecycleDebugPanel />""",
        ]
        addition = """

            <div className=\"mt-4\">
              <BoothDiskPersistencePanel />
            </div>

            <div className=\"mt-4\">
              <BoothDiskBrowserPanel />
            </div>

            <div className=\"mt-4\">
              <BoothDiskRetentionPanel />
            </div>"""
        patched = False
        for marker in markers:
            if marker in text:
                text = text.replace(marker, marker + addition, 1)
                patched = True
                break
        if not patched:
            print('WARN: BoothCustomerScreen marker not found; disk panels not inserted.')

    path.write_text(text)
    print('PATCH:', path)
else:
    print('WARN: BoothCustomerScreen.tsx not found.')
PY

python - <<'PY'
from pathlib import Path

path = Path('apps/booth-ui/src/booth/BoothDeliveryStep.tsx')
if path.exists():
    text = path.read_text()
    import_line = "import { BoothDeliveryDiskPanel } from './BoothDeliveryDiskPanel';"
    if import_line not in text:
        lines = text.splitlines()
        insert_at = 0
        for index, existing in enumerate(lines):
            if existing.startswith('import '):
                insert_at = index + 1
        lines.insert(insert_at, import_line)
        text = '\n'.join(lines) + '\n'

    if '<BoothDeliveryDiskPanel />' not in text:
        markers = [
            """      </aside>\n    </div>\n  );""",
            """    </div>\n  );""",
        ]
        replacement_done = False
        for marker in markers:
            if marker in text:
                if marker.startswith('      </aside>'):
                    replacement = """      </aside>

      <div className=\"xl:col-span-2\">
        <BoothDeliveryDiskPanel />
      </div>
    </div>
  );"""
                else:
                    replacement = """      <div className=\"mt-6\">
        <BoothDeliveryDiskPanel />
      </div>
    </div>
  );"""
                text = text.replace(marker, replacement, 1)
                replacement_done = True
                break
        if not replacement_done:
            print('WARN: Delivery closing marker not found; disk delivery panel not inserted.')

    path.write_text(text)
    print('PATCH:', path)
else:
    print('WARN: BoothDeliveryStep.tsx not found.')
PY

cat >> apps/booth-ui/src/booth/index.ts <<'TS'
export * from './booth-disk-persistence-types';
export * from './booth-disk-persistence-api';
export * from './booth-disk-persistence-storage';
export * from './booth-disk-manifest';
export * from './BoothDiskPersistencePanel';
export * from './BoothDiskBrowserPanel';
export * from './BoothDiskRetentionPanel';
export * from './BoothDeliveryDiskPanel';
TS

python - <<'PY'
from pathlib import Path
path = Path('apps/booth-ui/src/booth/index.ts')
if path.exists():
    lines = path.read_text().splitlines()
    seen = set()
    out = []
    for line in lines:
        if line.startswith('export * from '):
            if line in seen:
                continue
            seen.add(line)
        out.append(line)
    path.write_text('\n'.join(out) + '\n')
PY

cat > docs/phase-9e-electron-disk-persistence-checklist.md <<'MD'
# Phase 9E — Electron Disk Persistence Checklist

Status: code scaffold complete after TypeScript passes.

Completed:
- 9E1 Electron disk IPC module
- 9E2 Preload `window.corraDisk` bridge
- 9E3 Frontend disk persistence API
- 9E4 Local disk record registry
- 9E5 Dev/Admin disk persistence panel
- 9E6 Disk file browser and delete action
- 9E7 Disk retention cleanup
- 9E8 Delivery-step disk save panel and docs/checker

Output folder:

```txt
Electron app userData/corra-booth-output/<sessionId>/<kind>/...
```

Manual Electron patch fallback:

If the script cannot patch your Electron main/preload automatically, add these manually.

Main process:

```js
const { registerCorraDiskPersistence } = require('./corra-disk-persistence.cjs');
registerCorraDiskPersistence({ ipcMain, app, shell, dialog });
```

Preload:

```js
const { installCorraDiskBridge } = require('./corra-disk-preload.cjs');
installCorraDiskBridge({ contextBridge, ipcRenderer });
```
MD

cat > docs/phase-9e-status.md <<'MD'
# Phase 9E Status

9E1 Electron disk IPC: done
9E2 Preload bridge: done
9E3 Frontend API: done
9E4 Registry storage: done
9E5 Persistence panel: done
9E6 Disk browser: done
9E7 Retention cleanup: done
9E8 Close checklist: done

Next recommended phase:
- 9F Printer + kiosk hardware testing
- 9G Packaging / release candidate
MD

cat > scripts/check-phase-9e-status.sh <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail

f(){ [ -f "$2" ] && echo "✅ $1" || echo "❌ $1"; }

echo "Phase 9E Status"
echo "==============="

f "9E1 Electron IPC" apps/desktop-electron/corra-disk-persistence.cjs
f "9E2 Preload bridge" apps/desktop-electron/corra-disk-preload.cjs
f "9E3 Disk types" apps/booth-ui/src/booth/booth-disk-persistence-types.ts
f "9E3 Disk API" apps/booth-ui/src/booth/booth-disk-persistence-api.ts
f "9E4 Disk storage" apps/booth-ui/src/booth/booth-disk-persistence-storage.ts
f "9E4 Manifest" apps/booth-ui/src/booth/booth-disk-manifest.ts
f "9E5 Persistence panel" apps/booth-ui/src/booth/BoothDiskPersistencePanel.tsx
f "9E6 Browser panel" apps/booth-ui/src/booth/BoothDiskBrowserPanel.tsx
f "9E7 Retention panel" apps/booth-ui/src/booth/BoothDiskRetentionPanel.tsx
f "9E8 Delivery panel" apps/booth-ui/src/booth/BoothDeliveryDiskPanel.tsx
f "9E8 Checklist" docs/phase-9e-electron-disk-persistence-checklist.md

echo ""
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
CHECK

chmod +x scripts/check-phase-9e-status.sh

echo "9E integration/docs/checker written."
