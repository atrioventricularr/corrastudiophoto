# Phase 9F Full Code — Printer/Kiosk Hardware Testing

Run from repo root:

```bash
cd /workspaces/corrastudiophoto

unzip phase-9f-full-code.zip -d /tmp
bash /tmp/phase-9f-full-code/run-phase-9f-full.sh

pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
./scripts/check-phase-9f-status.sh
```

Phase 9F includes:
- Electron hardware diagnostics IPC
- Preload bridge `window.corraHardware`
- Runtime diagnostics panel
- Printer discovery and print test
- Camera discovery and preview test
- Fullscreen/kiosk runtime controls
- Production readiness checklist
- Electron CJS bridge patch
- Docs/checker

Test inside Electron, because `window.corraHardware` is not available in browser Vite.
