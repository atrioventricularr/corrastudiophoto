#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "================================================="
echo " Phase 9E Full — Electron Disk Persistence"
echo "================================================="

bash "$ROOT_DIR/patches/01-electron-disk-ipc.sh"
bash "$ROOT_DIR/patches/02-ui-api-storage.sh"
bash "$ROOT_DIR/patches/03-ui-panels.sh"
bash "$ROOT_DIR/patches/04-integrate-docs.sh"

echo ""
echo "Phase 9E full code applied. Next run:"
echo "pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false"
echo "./scripts/check-phase-9e-status.sh"
echo ""
echo "Then test inside Electron, not only browser Vite."
