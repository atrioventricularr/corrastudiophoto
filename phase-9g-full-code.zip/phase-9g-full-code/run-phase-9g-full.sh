#!/usr/bin/env bash
set -euo pipefail

echo "================================================="
echo " Phase 9G Full — Packaging / Release Candidate"
echo "================================================="

mkdir -p apps/booth-ui/src/booth docs scripts release

cat > apps/booth-ui/src/booth/booth-release-types.ts <<'TS'
export type BoothReleaseCheckStatus = 'untested' | 'passed' | 'warning' | 'failed';

export type BoothReleaseCheckCategory =
  | 'build'
  | 'electron'
  | 'payment'
  | 'cloud'
  | 'disk'
  | 'hardware'
  | 'kiosk'
  | 'content'
  | 'release';

export type BoothReleaseCheckRecord = {
  id: string;
  label: string;
  category: BoothReleaseCheckCategory;
  status: BoothReleaseCheckStatus;
  message?: string;
  updatedAt: string;
};

export type BoothReleaseSummary = {
  required: number;
  passed: number;
  warnings: number;
  failed: number;
  ready: boolean;
  missingLabels: string[];
};
TS

cat > apps/booth-ui/src/booth/booth-release-readiness-storage.ts <<'TS'
import type {
  BoothReleaseCheckCategory,
  BoothReleaseCheckRecord,
  BoothReleaseCheckStatus,
  BoothReleaseSummary,
} from './booth-release-types';

const RELEASE_CHECKS_KEY = 'corra.booth.release.checks.v1';

export const REQUIRED_RELEASE_CHECKS = [
  'TypeScript clean',
  'Booth UI build',
  'Electron runtime opens',
  'License activation works',
  'Payment method configured',
  'Cloud upload configured',
  'Disk persistence works',
  'Printer detected',
  'Camera detected',
  'Kiosk mode tested',
  'Admin unlock tested',
  'Final delivery tested',
];

function makeId(label: string) {
  return `release-check-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
}

export function loadBoothReleaseCheckRecords(): BoothReleaseCheckRecord[] {
  if (typeof window === 'undefined') return [];

  try {
    const raw = window.localStorage.getItem(RELEASE_CHECKS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((record) => record && typeof record.id === 'string');
  } catch {
    return [];
  }
}

export function saveBoothReleaseCheckRecords(records: BoothReleaseCheckRecord[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(RELEASE_CHECKS_KEY, JSON.stringify(records));
}

export function upsertBoothReleaseCheckRecord(input: {
  label: string;
  category: BoothReleaseCheckCategory;
  status: BoothReleaseCheckStatus;
  message?: string;
}) {
  const records = loadBoothReleaseCheckRecords();
  const id = makeId(input.label);
  const nextRecord: BoothReleaseCheckRecord = {
    id,
    label: input.label,
    category: input.category,
    status: input.status,
    message: input.message,
    updatedAt: new Date().toISOString(),
  };

  const nextRecords = [...records.filter((record) => record.id !== id), nextRecord];
  saveBoothReleaseCheckRecords(nextRecords);
  return nextRecord;
}

export function clearBoothReleaseCheckRecords() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(RELEASE_CHECKS_KEY);
}

export function summarizeBoothReleaseReadiness(
  records: BoothReleaseCheckRecord[],
): BoothReleaseSummary {
  const passedLabels = new Set(
    records.filter((record) => record.status === 'passed').map((record) => record.label),
  );
  const missingLabels = REQUIRED_RELEASE_CHECKS.filter((label) => !passedLabels.has(label));

  return {
    required: REQUIRED_RELEASE_CHECKS.length,
    passed: REQUIRED_RELEASE_CHECKS.length - missingLabels.length,
    warnings: records.filter((record) => record.status === 'warning').length,
    failed: records.filter((record) => record.status === 'failed').length,
    ready: missingLabels.length === 0,
    missingLabels,
  };
}
TS

cat > apps/booth-ui/src/booth/booth-release-diagnostics.ts <<'TS'
import {
  getBoothHardwareRuntimeInfo,
  isCorraHardwareBridgeAvailable,
  listBoothHardwarePrinters,
} from './booth-hardware-api';
import { loadBoothCloudUploadRecords } from './booth-cloud-upload-storage';
import { loadBoothDiskRecords } from './booth-disk-storage';
import { loadBoothHardwareTestRecords } from './booth-hardware-test-storage';
import { upsertBoothReleaseCheckRecord } from './booth-release-readiness-storage';

function getPaymentConfiguredMessage() {
  try {
    const raw = window.localStorage.getItem('corra.payment.settings.v1');
    if (!raw) return 'Payment settings not found yet.';
    return 'Payment settings found in localStorage.';
  } catch {
    return 'Unable to inspect payment settings.';
  }
}

export async function runBoothReleaseDiagnostics() {
  const results: Array<{ label: string; ok: boolean; message: string }> = [];
  const hardwareBridge = isCorraHardwareBridgeAvailable();

  upsertBoothReleaseCheckRecord({
    label: 'Electron runtime opens',
    category: 'electron',
    status: hardwareBridge ? 'passed' : 'warning',
    message: hardwareBridge
      ? 'Electron hardware bridge is available.'
      : 'Hardware bridge unavailable in browser. Test inside Electron.',
  });

  results.push({
    label: 'Electron runtime opens',
    ok: hardwareBridge,
    message: hardwareBridge ? 'Bridge available.' : 'Bridge unavailable.',
  });

  if (hardwareBridge) {
    const runtime = await getBoothHardwareRuntimeInfo();
    results.push({
      label: 'Runtime info',
      ok: runtime.ok,
      message: runtime.ok ? 'Runtime info loaded.' : runtime.error || 'Runtime failed.',
    });

    const printers = await listBoothHardwarePrinters();
    upsertBoothReleaseCheckRecord({
      label: 'Printer detected',
      category: 'hardware',
      status: printers.ok && printers.printers.length > 0 ? 'passed' : 'warning',
      message:
        printers.ok && printers.printers.length > 0
          ? `${printers.printers.length} printer(s) detected.`
          : printers.error || 'No printer detected.',
    });
  }

  const paymentMessage = getPaymentConfiguredMessage();
  upsertBoothReleaseCheckRecord({
    label: 'Payment method configured',
    category: 'payment',
    status: paymentMessage.includes('found') ? 'passed' : 'warning',
    message: paymentMessage,
  });

  const cloudRecords = loadBoothCloudUploadRecords();
  upsertBoothReleaseCheckRecord({
    label: 'Cloud upload configured',
    category: 'cloud',
    status: import.meta.env.VITE_UPLOAD_BOOTH_ASSET_URL ? 'passed' : 'warning',
    message:
      cloudRecords.length > 0
        ? `${cloudRecords.length} cloud upload record(s) found.`
        : 'Cloud env checked; no upload record yet.',
  });

  const diskRecords = loadBoothDiskRecords();
  upsertBoothReleaseCheckRecord({
    label: 'Disk persistence works',
    category: 'disk',
    status: diskRecords.length > 0 ? 'passed' : 'warning',
    message:
      diskRecords.length > 0
        ? `${diskRecords.length} disk record(s) found.`
        : 'No disk record yet. Save an output inside Electron.',
  });

  const hardwareRecords = loadBoothHardwareTestRecords();
  const cameraPassed = hardwareRecords.some(
    (record) => record.label === 'Camera discovery' && record.status === 'passed',
  );
  const kioskPassed = hardwareRecords.some(
    (record) => record.label === 'Kiosk on' && record.status === 'passed',
  );

  upsertBoothReleaseCheckRecord({
    label: 'Camera detected',
    category: 'hardware',
    status: cameraPassed ? 'passed' : 'warning',
    message: cameraPassed ? 'Camera test passed.' : 'Run camera hardware test.',
  });

  upsertBoothReleaseCheckRecord({
    label: 'Kiosk mode tested',
    category: 'kiosk',
    status: kioskPassed ? 'passed' : 'warning',
    message: kioskPassed ? 'Kiosk test passed.' : 'Run kiosk hardware test.',
  });

  return results;
}
TS

cat > apps/booth-ui/src/booth/BoothReleaseDiagnosticsPanel.tsx <<'TSX'
import React, { useState } from 'react';
import { runBoothReleaseDiagnostics } from './booth-release-diagnostics';

export function BoothReleaseDiagnosticsPanel() {
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<Array<{ label: string; ok: boolean; message: string }>>([]);
  const [error, setError] = useState('');

  const runDiagnostics = async () => {
    setIsRunning(true);
    setError('');

    try {
      setResults(await runBoothReleaseDiagnostics());
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : 'Release diagnostics failed.');
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Release Diagnostics
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Pulls payment/cloud/disk/hardware signals into release readiness.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void runDiagnostics()}
          disabled={isRunning}
          className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950 disabled:opacity-40"
        >
          {isRunning ? 'Running...' : 'Run Diagnostics'}
        </button>
      </div>

      {error && (
        <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">
          {error}
        </div>
      )}

      <div className="mt-4 grid gap-2">
        {results.map((result) => (
          <div
            key={result.label}
            className={`rounded-2xl p-3 ${result.ok ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}
          >
            <p className="text-xs font-black uppercase tracking-[0.14em] text-white">
              {result.ok ? '✅' : '⚠️'} {result.label}
            </p>
            <p className="mt-1 text-[11px] font-bold text-white/55">{result.message}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothReleaseReadinessPanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import {
  clearBoothReleaseCheckRecords,
  loadBoothReleaseCheckRecords,
  REQUIRED_RELEASE_CHECKS,
  summarizeBoothReleaseReadiness,
  upsertBoothReleaseCheckRecord,
} from './booth-release-readiness-storage';
import type { BoothReleaseCheckCategory, BoothReleaseCheckStatus } from './booth-release-types';

function categoryFor(label: string): BoothReleaseCheckCategory {
  if (label.includes('TypeScript') || label.includes('build')) return 'build';
  if (label.includes('Electron')) return 'electron';
  if (label.includes('Payment')) return 'payment';
  if (label.includes('Cloud')) return 'cloud';
  if (label.includes('Disk')) return 'disk';
  if (label.includes('Printer') || label.includes('Camera')) return 'hardware';
  if (label.includes('Kiosk') || label.includes('unlock')) return 'kiosk';
  if (label.includes('delivery')) return 'content';
  return 'release';
}

export function BoothReleaseReadinessPanel() {
  const [records, setRecords] = useState(() => loadBoothReleaseCheckRecords());
  const summary = useMemo(() => summarizeBoothReleaseReadiness(records), [records]);
  const refresh = () => setRecords(loadBoothReleaseCheckRecords());

  const mark = (label: string, status: BoothReleaseCheckStatus) => {
    upsertBoothReleaseCheckRecord({
      label,
      category: categoryFor(label),
      status,
      message: status === 'passed' ? 'Manually marked as passed.' : 'Manual review required.',
    });
    refresh();
  };

  const clear = () => {
    clearBoothReleaseCheckRecords();
    refresh();
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">
            Release Candidate Readiness
          </p>
          <p className="mt-1 text-sm font-bold text-white/60">
            Checklist sebelum Corra Booth dipaketkan sebagai release candidate.
          </p>
        </div>

        <div
          className={`rounded-2xl px-3 py-2 text-xs font-black ${
            summary.ready ? 'bg-emerald-500/20 text-emerald-100' : 'bg-amber-500/20 text-amber-100'
          }`}
        >
          {summary.ready ? 'RC READY' : 'NOT READY'} · {summary.passed}/{summary.required}
        </div>
      </div>

      <div className="mt-4 grid gap-2">
        {REQUIRED_RELEASE_CHECKS.map((label) => {
          const record = records.find((item) => item.label === label);
          const passed = record?.status === 'passed';

          return (
            <div key={label} className={`rounded-2xl p-3 ${passed ? 'bg-emerald-500/20' : 'bg-white/10'}`}>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-white">
                    {passed ? '✅' : '⬜'} {label}
                  </p>
                  {record?.message && (
                    <p className="mt-1 text-[11px] font-bold text-white/50">{record.message}</p>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => mark(label, 'passed')}
                    className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"
                  >
                    Pass
                  </button>
                  <button
                    type="button"
                    onClick={() => mark(label, 'warning')}
                    className="rounded-2xl border border-amber-300/30 bg-amber-500/20 px-3 py-2 text-xs font-black text-amber-100"
                  >
                    Warn
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <button type="button" onClick={refresh} className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950">
          Refresh
        </button>
        <button
          type="button"
          onClick={clear}
          className="rounded-2xl border border-red-300/30 bg-red-500/20 px-3 py-2 text-xs font-black text-red-100"
        >
          Clear Release Checks
        </button>
      </div>

      {!summary.ready && (
        <div className="mt-4 rounded-2xl bg-amber-500/20 p-3 text-xs font-bold text-amber-100">
          Missing: {summary.missingLabels.join(', ')}
        </div>
      )}
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothReleaseManifestPanel.tsx <<'TSX'
import React, { useMemo } from 'react';

export function BoothReleaseManifestPanel() {
  const manifest = useMemo(() => {
    return {
      appName: 'Corra Booth',
      version: import.meta.env.VITE_CORRA_APP_VERSION || '0.0.0-dev',
      buildId: import.meta.env.VITE_CORRA_BUILD_ID || 'local-dev',
      channel: import.meta.env.VITE_CORRA_RELEASE_CHANNEL || 'dev',
      commit: import.meta.env.VITE_CORRA_COMMIT || 'unknown',
      builtAt: import.meta.env.VITE_CORRA_BUILT_AT || 'runtime',
    };
  }, []);

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">Release Manifest</p>
      <pre className="mt-4 overflow-auto rounded-2xl bg-black/40 p-3 text-[11px] font-bold text-white/60">
        {JSON.stringify(manifest, null, 2)}
      </pre>
    </section>
  );
}
TSX

python - <<'PY'
from pathlib import Path

path = Path('apps/booth-ui/src/booth/BoothCustomerScreen.tsx')
if not path.exists():
    raise SystemExit('BoothCustomerScreen.tsx not found')
text = path.read_text()
imports = [
    "import { BoothReleaseDiagnosticsPanel } from './BoothReleaseDiagnosticsPanel';",
    "import { BoothReleaseReadinessPanel } from './BoothReleaseReadinessPanel';",
    "import { BoothReleaseManifestPanel } from './BoothReleaseManifestPanel';",
]
for line in imports:
    if line not in text:
        lines = text.splitlines()
        insert_at = 0
        for index, existing in enumerate(lines):
            if existing.startswith('import '):
                insert_at = index + 1
        lines.insert(insert_at, line)
        text = '\n'.join(lines) + '\n'

panel_block = """
            <div className=\"mt-4\">
              <BoothReleaseDiagnosticsPanel />
            </div>

            <div className=\"mt-4\">
              <BoothReleaseReadinessPanel />
            </div>

            <div className=\"mt-4\">
              <BoothReleaseManifestPanel />
            </div>"""

if '<BoothReleaseReadinessPanel />' not in text:
    markers = [
        """            <div className=\"mt-4\">
              <BoothProductionReadinessPanel />
            </div>""",
        """            <div className=\"mt-4\">
              <BoothCloudCleanupPanel />
            </div>""",
        """            <div className=\"mt-4\">
              <BoothLocalAssetsPanel />
            </div>""",
    ]
    for marker in markers:
        if marker in text:
            text = text.replace(marker, marker + '\n' + panel_block, 1)
            break
    else:
        print('WARN: No dev panel marker found. Release panels not inserted.')

path.write_text(text)
print('PATCH:', path)
PY

cat >> apps/booth-ui/src/booth/index.ts <<'TS'
export * from './booth-release-types';
export * from './booth-release-readiness-storage';
export * from './booth-release-diagnostics';
export * from './BoothReleaseDiagnosticsPanel';
export * from './BoothReleaseReadinessPanel';
export * from './BoothReleaseManifestPanel';
TS

python - <<'PY'
from pathlib import Path
path = Path('apps/booth-ui/src/booth/index.ts')
lines = path.read_text().splitlines()
seen = set()
out = []
for line in lines:
    if line.startswith('export * from '):
        if line in seen:
            continue
        seen.add(line)
    out.append(line)
path.write_text('\n'.join(out) + '\n')
PY

cat > scripts/corra-release-env.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

export CORRA_APP_NAME="${CORRA_APP_NAME:-Corra Booth}"
export CORRA_APP_VERSION="${CORRA_APP_VERSION:-0.9.0-rc.1}"
export CORRA_RELEASE_CHANNEL="${CORRA_RELEASE_CHANNEL:-rc}"
export CORRA_BUILD_ID="${CORRA_BUILD_ID:-$(date +%Y%m%d%H%M%S)}"
export CORRA_COMMIT="${CORRA_COMMIT:-$(git rev-parse --short HEAD 2>/dev/null || echo unknown)}"
export CORRA_BUILT_AT="${CORRA_BUILT_AT:-$(date -Iseconds)}"

echo "CORRA_APP_NAME=$CORRA_APP_NAME"
echo "CORRA_APP_VERSION=$CORRA_APP_VERSION"
echo "CORRA_RELEASE_CHANNEL=$CORRA_RELEASE_CHANNEL"
echo "CORRA_BUILD_ID=$CORRA_BUILD_ID"
echo "CORRA_COMMIT=$CORRA_COMMIT"
echo "CORRA_BUILT_AT=$CORRA_BUILT_AT"
SH

cat > scripts/build-booth-ui-release.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
source scripts/corra-release-env.sh

export VITE_CORRA_APP_VERSION="$CORRA_APP_VERSION"
export VITE_CORRA_RELEASE_CHANNEL="$CORRA_RELEASE_CHANNEL"
export VITE_CORRA_BUILD_ID="$CORRA_BUILD_ID"
export VITE_CORRA_COMMIT="$CORRA_COMMIT"
export VITE_CORRA_BUILT_AT="$CORRA_BUILT_AT"

pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
pnpm --filter @corra/booth-ui build
SH

cat > scripts/make-corra-release-candidate.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
source scripts/corra-release-env.sh

RELEASE_ROOT="release/corra-booth-${CORRA_APP_VERSION}-${CORRA_BUILD_ID}"
BUNDLE_DIR="$RELEASE_ROOT/bundle"
mkdir -p "$BUNDLE_DIR"

bash scripts/build-booth-ui-release.sh

mkdir -p "$BUNDLE_DIR/apps" "$BUNDLE_DIR/docs"
cp -R apps/booth-ui/dist "$BUNDLE_DIR/booth-ui-dist"
cp -R apps/desktop-electron "$BUNDLE_DIR/apps/desktop-electron"
cp docs/phase-9g-packaging-release-checklist.md "$BUNDLE_DIR/docs/" 2>/dev/null || true
cp docs/phase-9f-printer-kiosk-hardware-checklist.md "$BUNDLE_DIR/docs/" 2>/dev/null || true
cp docs/phase-9e-electron-disk-persistence-checklist.md "$BUNDLE_DIR/docs/" 2>/dev/null || true

cat > "$BUNDLE_DIR/release-manifest.json" <<JSON
{
  "appName": "$CORRA_APP_NAME",
  "version": "$CORRA_APP_VERSION",
  "channel": "$CORRA_RELEASE_CHANNEL",
  "buildId": "$CORRA_BUILD_ID",
  "commit": "$CORRA_COMMIT",
  "builtAt": "$CORRA_BUILT_AT",
  "notes": [
    "Release candidate bundle generated by scripts/make-corra-release-candidate.sh",
    "Test in Electron before distribution.",
    "Do not commit secrets or .env.local into public releases."
  ]
}
JSON

cat > "$BUNDLE_DIR/RUN-ELECTRON-WINDOWS.cmd" <<'CMD'
@echo off
setlocal
cd /d "%~dp0"
echo Corra Booth release bundle
echo.
echo Use the project Electron launcher / vendor Electron path for final Windows testing.
echo This bundle is a release candidate archive, not a signed installer yet.
echo.
pause
CMD

cat > "$RELEASE_ROOT/README.txt" <<TXT
Corra Booth Release Candidate

Version: $CORRA_APP_VERSION
Build ID: $CORRA_BUILD_ID
Commit: $CORRA_COMMIT
Built At: $CORRA_BUILT_AT

Contents:
- bundle/booth-ui-dist
- bundle/apps/desktop-electron
- bundle/release-manifest.json

Next:
1. Test in Electron on Windows.
2. Verify license activation.
3. Verify payment flow.
4. Verify camera/printer/kiosk.
5. Verify disk/cloud delivery.
TXT

echo "Release candidate generated: $RELEASE_ROOT"
SH

cat > scripts/check-corra-release-candidate.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "Corra Release Candidate Check"
echo "============================="
f(){ [ -e "$2" ] && echo "✅ $1" || echo "❌ $1"; }

f "booth package" apps/booth-ui/package.json
f "booth dist" apps/booth-ui/dist
f "desktop electron" apps/desktop-electron
f "electron main" apps/desktop-electron/main.cjs
f "electron preload" apps/desktop-electron/preload.cjs
f "disk bridge" apps/desktop-electron/corra-disk-persistence.cjs
f "hardware bridge" apps/desktop-electron/corra-hardware-diagnostics.cjs
f "9G docs" docs/phase-9g-packaging-release-checklist.md

echo ""
echo "Latest release folders:"
find release -maxdepth 1 -type d -name "corra-booth-*" -print 2>/dev/null | sort | tail -5 || true
SH

chmod +x scripts/corra-release-env.sh
chmod +x scripts/build-booth-ui-release.sh
chmod +x scripts/make-corra-release-candidate.sh
chmod +x scripts/check-corra-release-candidate.sh

python - <<'PY'
from pathlib import Path
import json
path = Path('package.json')
if not path.exists():
    print('WARN: root package.json not found; skip script patch')
    raise SystemExit(0)
data = json.loads(path.read_text())
scripts = data.setdefault('scripts', {})
scripts.setdefault('corra:release:build-ui', 'bash scripts/build-booth-ui-release.sh')
scripts.setdefault('corra:release:make-rc', 'bash scripts/make-corra-release-candidate.sh')
scripts.setdefault('corra:release:check', 'bash scripts/check-corra-release-candidate.sh')
path.write_text(json.dumps(data, indent=2) + '\n')
print('PATCH:', path)
PY

cat > docs/phase-9g-packaging-release-checklist.md <<'MD'
# Phase 9G — Packaging / Release Candidate Checklist

Status: code scaffold complete after typecheck passes.

Completed:
- 9G1 Release readiness types/storage
- 9G2 Release diagnostics helper
- 9G3 Release diagnostics/readiness UI panels
- 9G4 Release manifest panel
- 9G5 Booth dev integration
- 9G6 Export wiring
- 9G7 Build/package scripts
- 9G8 Root package script helpers
- 9G9 Docs/checker
- 9G10 Phase 9 close status

Commands:
```bash
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
bash scripts/build-booth-ui-release.sh
bash scripts/make-corra-release-candidate.sh
bash scripts/check-corra-release-candidate.sh
```

Manual QA:
1. Run inside Electron.
2. Activate license.
3. Test payment flow.
4. Test camera preview/capture.
5. Test final render.
6. Test disk save.
7. Test cloud upload/share link.
8. Test printer.
9. Test kiosk fullscreen/admin unlock.
10. Mark Release Candidate Readiness as passed.

Known limitation:
- This phase creates a release candidate bundle, not a signed Windows installer.
- Signed installer can be Phase 10 / production distribution hardening.
MD

cat > docs/phase-9g-status.md <<'MD'
# Phase 9G Status

9G1 done
9G2 done
9G3 done
9G4 done
9G5 done
9G6 done
9G7 done
9G8 done
9G9 done
9G10 done

Phase 9 overall status:
- 9A done
- 9B done
- 9C done
- 9D done
- 9E done
- 9F done
- 9G done

Next recommended:
- Phase 10: installer signing, licensing security hardening, cloud production policies, and final commercial distribution.
MD

cat > scripts/check-phase-9g-status.sh <<'CHECK'
#!/usr/bin/env bash
set -euo pipefail

f(){ [ -f "$2" ] && echo "✅ $1" || echo "❌ $1"; }

echo "Phase 9G Status"
echo "==============="
f "9G1 release types" apps/booth-ui/src/booth/booth-release-types.ts
f "9G1 readiness storage" apps/booth-ui/src/booth/booth-release-readiness-storage.ts
f "9G2 diagnostics" apps/booth-ui/src/booth/booth-release-diagnostics.ts
f "9G3 diagnostics panel" apps/booth-ui/src/booth/BoothReleaseDiagnosticsPanel.tsx
f "9G3 readiness panel" apps/booth-ui/src/booth/BoothReleaseReadinessPanel.tsx
f "9G4 manifest panel" apps/booth-ui/src/booth/BoothReleaseManifestPanel.tsx
f "9G7 release env" scripts/corra-release-env.sh
f "9G7 build UI" scripts/build-booth-ui-release.sh
f "9G7 make RC" scripts/make-corra-release-candidate.sh
f "9G7 check RC" scripts/check-corra-release-candidate.sh
f "9G9 docs" docs/phase-9g-packaging-release-checklist.md
f "9G10 status" docs/phase-9g-status.md

echo ""
pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
CHECK

chmod +x scripts/check-phase-9g-status.sh

echo ""
echo "Phase 9G full code applied."
echo "Next run:"
echo "pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false"
echo "./scripts/check-phase-9g-status.sh"
echo "bash scripts/make-corra-release-candidate.sh"
echo "bash scripts/check-corra-release-candidate.sh"
