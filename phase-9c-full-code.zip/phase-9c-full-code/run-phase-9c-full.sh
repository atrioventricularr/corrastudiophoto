#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

bash "$ROOT_DIR/patches/01-edge-functions.sh"
bash "$ROOT_DIR/patches/02-apis-utils.sh"
bash "$ROOT_DIR/patches/03-health-queue-panels.sh"
bash "$ROOT_DIR/patches/04-share-browser-cleanup.sh"
bash "$ROOT_DIR/patches/05-integrate-docs.sh"

echo ""
echo "Phase 9C full code applied. Next run:"
echo "pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false"
echo "./scripts/check-phase-9c-status.sh"
echo ""
echo "Deploy Edge Functions when typecheck is clean:"
echo "pnpm dlx supabase functions deploy refresh-booth-signed-url --no-verify-jwt"
echo "pnpm dlx supabase functions deploy delete-booth-cloud-asset --no-verify-jwt"
