#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/booth-ui/src/booth

cat > apps/booth-ui/src/booth/BoothDeliverySharePanel.tsx <<'TSX'
import QRCode from 'qrcode';
import React, { useEffect, useMemo, useState } from 'react';
import { loadBoothCloudUploadRecords } from './booth-cloud-upload-storage';
import { useBoothFlow } from './BoothFlowProvider';

export function BoothDeliverySharePanel() {
  const { session } = useBoothFlow();
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copyMessage, setCopyMessage] = useState('');
  const latestFinalRecord = useMemo(() => {
    const records = loadBoothCloudUploadRecords();
    return records.filter((record) => record.kind === 'final_output').filter((record) => !session?.id || record.sessionId === session.id).at(-1);
  }, [session?.id]);

  useEffect(() => {
    let cancelled = false;
    async function buildQr() {
      if (!latestFinalRecord?.signedUrl) { setQrDataUrl(''); return; }
      const nextQr = await QRCode.toDataURL(latestFinalRecord.signedUrl, { margin: 1, width: 320 });
      if (!cancelled) setQrDataUrl(nextQr);
    }
    void buildQr();
    return () => { cancelled = true; };
  }, [latestFinalRecord?.signedUrl]);

  const copyLink = async () => {
    if (!latestFinalRecord?.signedUrl) return;
    await navigator.clipboard.writeText(latestFinalRecord.signedUrl);
    setCopyMessage('Link copied.');
  };

  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/10 p-6">
      <p className="text-xs font-black uppercase tracking-[0.25em] text-white/50">Digital Share Link</p>
      {!latestFinalRecord && <div className="mt-4 rounded-2xl bg-black/20 p-4 text-sm font-bold text-white/60">Belum ada final output cloud link. Upload final output dulu dari dev panel Cloud Upload.</div>}
      {latestFinalRecord && (
        <div className="mt-4 grid gap-4 lg:grid-cols-[220px_1fr]">
          <div className="rounded-3xl bg-white p-4">{qrDataUrl ? <img src={qrDataUrl} alt="Digital copy QR" className="h-full w-full object-contain" /> : <div className="flex h-48 items-center justify-center text-sm font-bold text-slate-400">Generating QR...</div>}</div>
          <div>
            <p className="text-lg font-black text-white">Scan to download digital copy</p>
            <p className="mt-2 break-all text-xs font-bold text-white/50">{latestFinalRecord.signedUrl}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <a href={latestFinalRecord.signedUrl} target="_blank" rel="noreferrer" className="rounded-2xl bg-white px-4 py-3 text-xs font-black text-slate-950">Open Link</a>
              <button type="button" onClick={() => void copyLink()} className="rounded-2xl border border-white/15 bg-white/10 px-4 py-3 text-xs font-black text-white">Copy Link</button>
            </div>
            {copyMessage && <p className="mt-3 text-xs font-bold text-emerald-200">{copyMessage}</p>}
          </div>
        </div>
      )}
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothCloudAssetBrowserPanel.tsx <<'TSX'
import React, { useMemo, useState } from 'react';
import { deleteBoothCloudAsset } from './booth-cloud-delete-api';
import { getCloudUploadRecordState } from './booth-cloud-upload-health';
import { loadBoothCloudUploadRecords, saveBoothCloudUploadRecords } from './booth-cloud-upload-storage';
import { refreshBoothSignedUrl } from './booth-cloud-refresh-api';

export function BoothCloudAssetBrowserPanel() {
  const [records, setRecords] = useState(() => loadBoothCloudUploadRecords());
  const [filter, setFilter] = useState<'all' | 'raw_capture' | 'final_output'>('all');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const filteredRecords = useMemo(() => filter === 'all' ? records : records.filter((record) => record.kind === filter), [filter, records]);
  const updateRecords = (nextRecords: typeof records) => { saveBoothCloudUploadRecords(nextRecords); setRecords(nextRecords); };

  const refreshOne = async (recordId: string) => {
    setError('');
    const record = records.find((candidate) => candidate.id === recordId);
    if (!record) return;
    try {
      const refreshed = await refreshBoothSignedUrl(record);
      updateRecords(records.map((item) => item.id === recordId ? refreshed : item));
      setMessage('Signed link refreshed.');
    } catch (caughtError) { setError(caughtError instanceof Error ? caughtError.message : 'Refresh failed.'); }
  };

  const deleteOne = async (recordId: string) => {
    setError('');
    const record = records.find((candidate) => candidate.id === recordId);
    if (!record) return;
    try {
      await deleteBoothCloudAsset(record);
      updateRecords(records.filter((item) => item.id !== recordId));
      setMessage('Cloud asset deleted and local record removed.');
    } catch (caughtError) { setError(caughtError instanceof Error ? caughtError.message : 'Delete failed.'); }
  };

  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div><p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">Cloud Asset Browser</p><p className="mt-1 text-sm font-bold text-white/60">Browse, open, refresh, and delete uploaded cloud assets.</p></div>
        <select value={filter} onChange={(event) => setFilter(event.target.value as typeof filter)} className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950"><option value="all">All</option><option value="raw_capture">Raw</option><option value="final_output">Final</option></select>
      </div>
      {message && <div className="mt-4 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">{message}</div>}
      {error && <div className="mt-4 rounded-2xl border border-red-300/30 bg-red-500/20 p-3 text-xs font-bold text-red-100">{error}</div>}
      <div className="mt-4 grid gap-2">
        {filteredRecords.slice(-8).reverse().map((record) => (
          <div key={record.id} className="rounded-2xl bg-white/10 p-3">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-white">{record.kind} · {getCloudUploadRecordState(record)}</p>
            <p className="mt-1 break-all text-xs font-bold text-white/60">{record.filename}</p>
            <p className="mt-1 break-all font-mono text-[10px] font-bold text-white/35">{record.bucketName}/{record.storagePath}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <a href={record.signedUrl} target="_blank" rel="noreferrer" className="rounded-2xl bg-white px-3 py-2 text-xs font-black text-slate-950">Open</a>
              <button type="button" onClick={() => void refreshOne(record.id)} className="rounded-2xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-black text-white">Refresh Link</button>
              <button type="button" onClick={() => void deleteOne(record.id)} className="rounded-2xl border border-red-300/30 bg-red-500/20 px-3 py-2 text-xs font-black text-red-100">Delete Cloud</button>
            </div>
          </div>
        ))}
        {filteredRecords.length === 0 && <div className="rounded-2xl bg-white/10 p-3 text-xs font-bold text-white/50">No cloud asset records.</div>}
      </div>
    </section>
  );
}
TSX

cat > apps/booth-ui/src/booth/BoothCloudCleanupPanel.tsx <<'TSX'
import React, { useState } from 'react';
import { getCloudUploadRecordState } from './booth-cloud-upload-health';
import { loadBoothCloudUploadRecords, saveBoothCloudUploadRecords } from './booth-cloud-upload-storage';

export function BoothCloudCleanupPanel() {
  const [message, setMessage] = useState('');
  const clearExpiredLocalRecords = () => {
    const records = loadBoothCloudUploadRecords();
    const nextRecords = records.filter((record) => getCloudUploadRecordState(record) !== 'expired');
    saveBoothCloudUploadRecords(nextRecords);
    setMessage(`Removed ${records.length - nextRecords.length} expired local upload record(s).`);
  };
  const clearAllLocalRecords = () => { saveBoothCloudUploadRecords([]); setMessage('All local cloud upload records cleared.'); };
  return (
    <section className="rounded-3xl border border-white/10 bg-black/20 p-4">
      <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40">Cloud Cleanup</p>
      <p className="mt-1 text-sm font-bold text-white/60">Local upload record cleanup. Cloud object deletion tersedia di Cloud Asset Browser.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <button type="button" onClick={clearExpiredLocalRecords} className="rounded-2xl border border-amber-300/30 bg-amber-500/20 px-3 py-3 text-xs font-black text-amber-100">Clear Expired Local Records</button>
        <button type="button" onClick={clearAllLocalRecords} className="rounded-2xl border border-red-300/30 bg-red-500/20 px-3 py-3 text-xs font-black text-red-100">Clear All Local Records</button>
      </div>
      {message && <p className="mt-3 rounded-2xl bg-emerald-500/20 p-3 text-xs font-bold text-emerald-100">{message}</p>}
    </section>
  );
}
TSX

echo "9C share/browser/cleanup panels written."
