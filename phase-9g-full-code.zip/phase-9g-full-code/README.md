# Phase 9G Full Code — Packaging / Release Candidate

Run from repo root:

```bash
cd /workspaces/corrastudiophoto

unzip phase-9g-full-code.zip -d /tmp
bash /tmp/phase-9g-full-code/run-phase-9g-full.sh

pnpm --filter @corra/booth-ui exec tsc --noEmit --pretty false
./scripts/check-phase-9g-status.sh

bash scripts/make-corra-release-candidate.sh
bash scripts/check-corra-release-candidate.sh
```

This creates a release candidate bundle under `release/`. It is not yet a signed Windows installer.
