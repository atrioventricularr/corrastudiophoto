#!/usr/bin/env bash
set -euo pipefail

mkdir -p apps/booth-ui/src/booth

cat > apps/booth-ui/src/booth/booth-disk-persistence-types.ts <<'TS'
export type BoothDiskAssetKind =
  | 'raw_capture'
  | 'final_output'
  | 'print_ready'
  | 'manifest'
  | 'export'
  | 'other';

export type BoothDiskSaveDataUrlInput = {
  sessionId: string;
  kind: BoothDiskAssetKind | string;
  filename: string;
  dataUrl: string;
  metadata?: Record<string, unknown>;
};

export type BoothDiskSaveTextInput = {
  sessionId: string;
  kind: BoothDiskAssetKind | string;
  filename: string;
  text: string;
  mimeType?: string;
  metadata?: Record<string, unknown>;
};

export type BoothDiskFileRecord = {
  ok?: boolean;
  id: string;
  sessionId: string;
  kind: string;
  filename: string;
  mimeType?: string;
  sizeBytes: number;
  absolutePath?: string;
  relativePath: string;
  savedAt: string;
  metadata?: Record<string, unknown>;
};

export type BoothDiskListResult = {
  ok: boolean;
  rootPath?: string;
  files: Array<{
    path?: string;
    relativePath: string;
    filename: string;
    sizeBytes: number;
    modifiedAt: string;
  }>;
  error?: string;
};

export type BoothDiskActionResult = {
  ok: boolean;
  path?: string;
  rootPath?: string;
  relativePath?: string;
  deletedCount?: number;
  error?: string;
};

export type CorraDiskBridge = {
  getRoot: () => Promise<BoothDiskActionResult>;
  openOutputFolder: (payload?: { sessionId?: string }) => Promise<BoothDiskActionResult>;
  saveDataUrl: (payload: BoothDiskSaveDataUrlInput) => Promise<BoothDiskFileRecord>;
  saveTextFile: (payload: BoothDiskSaveTextInput) => Promise<BoothDiskFileRecord>;
  listSessionFiles: (payload?: { sessionId?: string }) => Promise<BoothDiskListResult>;
  deleteFile: (payload: { relativePath: string }) => Promise<BoothDiskActionResult>;
  cleanupOlderThanDays: (payload: { days: number }) => Promise<BoothDiskActionResult>;
};

declare global {
  interface Window {
    corraDisk?: CorraDiskBridge;
  }
}
TS

cat > apps/booth-ui/src/booth/booth-disk-persistence-api.ts <<'TS'
import type {
  BoothDiskActionResult,
  BoothDiskFileRecord,
  BoothDiskListResult,
  BoothDiskSaveDataUrlInput,
  BoothDiskSaveTextInput,
  CorraDiskBridge,
} from './booth-disk-persistence-types';

export function getCorraDiskBridge(): CorraDiskBridge | undefined {
  if (typeof window === 'undefined') return undefined;
  return window.corraDisk;
}

export function isCorraDiskAvailable() {
  return Boolean(getCorraDiskBridge());
}

function unavailable(): never {
  throw new Error('Electron disk persistence bridge is not available. Run inside Corra Electron app.');
}

export async function getBoothDiskRoot(): Promise<BoothDiskActionResult> {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.getRoot();
}

export async function openBoothDiskOutputFolder(sessionId?: string) {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.openOutputFolder({ sessionId });
}

export async function saveBoothDataUrlToDisk(
  payload: BoothDiskSaveDataUrlInput,
): Promise<BoothDiskFileRecord> {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.saveDataUrl(payload);
}

export async function saveBoothTextToDisk(
  payload: BoothDiskSaveTextInput,
): Promise<BoothDiskFileRecord> {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.saveTextFile(payload);
}

export async function listBoothDiskFiles(sessionId?: string): Promise<BoothDiskListResult> {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.listSessionFiles({ sessionId });
}

export async function deleteBoothDiskFile(relativePath: string) {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.deleteFile({ relativePath });
}

export async function cleanupBoothDiskOlderThanDays(days: number) {
  const bridge = getCorraDiskBridge();
  if (!bridge) unavailable();
  return bridge.cleanupOlderThanDays({ days });
}
TS

cat > apps/booth-ui/src/booth/booth-disk-persistence-storage.ts <<'TS'
import type { BoothDiskFileRecord } from './booth-disk-persistence-types';

const RECORDS_KEY = 'corra.booth.disk.persistence.records.v1';

export function loadBoothDiskRecords(): BoothDiskFileRecord[] {
  if (typeof window === 'undefined') return [];

  try {
    const raw = window.localStorage.getItem(RECORDS_KEY);
    if (!raw) return [];

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed.filter((record) => record && typeof record.id === 'string');
  } catch {
    return [];
  }
}

export function saveBoothDiskRecords(records: BoothDiskFileRecord[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(RECORDS_KEY, JSON.stringify(records.slice(-1000)));
}

export function appendBoothDiskRecord(record: BoothDiskFileRecord) {
  const records = loadBoothDiskRecords();
  const nextRecords = [...records.filter((item) => item.id !== record.id), record];
  saveBoothDiskRecords(nextRecords);
  return nextRecords;
}

export function clearBoothDiskRecords() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(RECORDS_KEY);
}

export function removeBoothDiskRecordByRelativePath(relativePath: string) {
  const records = loadBoothDiskRecords();
  const nextRecords = records.filter((record) => record.relativePath !== relativePath);
  saveBoothDiskRecords(nextRecords);
  return nextRecords;
}
TS

cat > apps/booth-ui/src/booth/booth-disk-manifest.ts <<'TS'
import type { BoothDiskFileRecord } from './booth-disk-persistence-types';

export function buildBoothDiskManifest(input: {
  sessionId: string;
  records: BoothDiskFileRecord[];
  extra?: Record<string, unknown>;
}) {
  return {
    app: 'Corra Booth',
    format: 'corra-booth-session-manifest-v1',
    sessionId: input.sessionId,
    exportedAt: new Date().toISOString(),
    assetCount: input.records.length,
    assets: input.records,
    extra: input.extra || {},
  };
}

export function makeBoothManifestFilename(sessionId: string) {
  const safeSessionId = sessionId.replace(/[^a-zA-Z0-9._-]+/g, '-');
  return `corra-session-${safeSessionId || 'unknown'}-manifest.json`;
}
TS

echo "9E2 UI disk API/storage files written."
